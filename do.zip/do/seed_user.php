<?php
/**
 * SEED USER - chạy 1 lần để tạo tài khoản đăng nhập.
 * Theo đề bài: username = MSSV, password = MSSV.
 *
 * Cách dùng:
 *  http://localhost/<project>/seed_user.php?mssv=PH37123
 *  (thay PH37123 bằng MSSV thật của bạn)
 *
 * XÓA file này sau khi seed xong.
 */

require_once './configs/env.php';

$mssv = $_GET['mssv'] ?? '';

if (empty($mssv)) {
    die('Vui lòng truyền MSSV, ví dụ: seed_user.php?mssv=PH37123');
}

try {
    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8', DB_HOST, DB_PORT, DB_NAME);
    $pdo = new PDO($dsn, DB_USERNAME, DB_PASSWORD, DB_OPTIONS);

    $hashedPassword = password_hash($mssv, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare('SELECT user_id FROM users WHERE username = :username');
    $stmt->execute(['username' => $mssv]);
    $user = $stmt->fetch();

    if ($user) {
        $stmt = $pdo->prepare('UPDATE users SET password = :password WHERE username = :username');
        $stmt->execute(['password' => $hashedPassword, 'username' => $mssv]);
        echo "Đã cập nhật lại mật khẩu cho tài khoản: <b>{$mssv}</b>";
    } else {
        $stmt = $pdo->prepare('INSERT INTO users (username, password) VALUES (:username, :password)');
        $stmt->execute(['username' => $mssv, 'password' => $hashedPassword]);
        echo "Tạo tài khoản thành công! Đăng nhập bằng username/password: <b>{$mssv}</b>";
    }

    echo '<br><br><i>Hãy xóa file seed_user.php này sau khi dùng xong.</i>';
} catch (PDOException $e) {
    die('Lỗi kết nối / thao tác CSDL: ' . $e->getMessage());
}
