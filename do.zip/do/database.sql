-- ====================================================
-- Database: mmasv_examphp1
-- ĐỀ 4 - Quản lý Sách / Thể loại
-- ====================================================

CREATE DATABASE IF NOT EXISTS mmasv_examphp1
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mmasv_examphp1;

-- ----------------------------------------------------
-- Bảng the_loai
-- ----------------------------------------------------
CREATE TABLE IF NOT EXISTS the_loai (
    id_the_loai   INT AUTO_INCREMENT PRIMARY KEY,
    ten_the_loai  VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO the_loai (ten_the_loai) VALUES
('Tiểu thuyết'),
('Khoa học'),
('Lịch sử');

-- ----------------------------------------------------
-- Bảng sach
-- ----------------------------------------------------
CREATE TABLE IF NOT EXISTS sach (
    id_sach       INT AUTO_INCREMENT PRIMARY KEY,
    ten_sach      VARCHAR(150) NOT NULL,
    tac_gia       VARCHAR(100) NULL,
    nam_xuat_ban  YEAR NULL,
    nha_xuat_ban  VARCHAR(150) NULL,
    hinh_anh      VARCHAR(255) NULL DEFAULT NULL,
    id_the_loai   INT NULL,
    CONSTRAINT fk_sach_the_loai
        FOREIGN KEY (id_the_loai) REFERENCES the_loai(id_the_loai)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Vài bản ghi mẫu (không bắt buộc, tiện demo)
INSERT INTO sach (ten_sach, tac_gia, nam_xuat_ban, nha_xuat_ban, hinh_anh, id_the_loai) VALUES
('Số đỏ', 'Vũ Trọng Phụng', 1936, 'NXB Văn học', NULL, 1),
('Lược sử thời gian', 'Stephen Hawking', 1988, 'NXB Trẻ', NULL, 2);

-- ----------------------------------------------------
-- Bảng users (đăng nhập bằng SESSION)
-- username = password = MSSV
-- ----------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id  INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Mật khẩu sẽ được tạo bằng password_hash() qua file seed_user.php (xem README)
