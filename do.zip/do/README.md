# Hướng dẫn cài đặt & chạy ĐỀ 4 - Quản lý Sách / Thể loại

## 1. Cấu trúc project

```
de4/
├── assets/uploads/         (nơi lưu ảnh sách upload lên)
├── configs/
│   ├── env.php             cấu hình DB (mmasv_examphp1) + các hằng đường dẫn
│   └── helper.php          upload_file, redirect, e(), require_login(), is_logged_in()
├── controllers/
│   ├── HomeController.php  trang chủ -> chuyển vào danh sách sách
│   ├── AuthController.php  đăng nhập / đăng xuất bằng SESSION
│   └── SachController.php  CRUD sách (index/create/store/edit/update/delete)
├── models/
│   ├── BaseModel.php       kết nối PDO
│   ├── TheLoai.php         lấy danh sách thể loại (combobox)
│   ├── Sach.php            CRUD sách, JOIN the_loai
│   └── User.php            kiểm tra đăng nhập
├── routes/
│   └── index.php           định tuyến action -> Controller
├── views/
│   ├── main.php             layout chung (navbar có tên người đăng nhập)
│   ├── auth/login.php       form đăng nhập
│   └── sach/
│       ├── list.php         danh sách sách
│       └── form.php         form thêm/sửa sách
├── index.php                front controller (autoload, session_start)
├── seed_user.php             (tạm thời) tạo tài khoản đăng nhập
└── database.sql              script tạo database
```

## 2. Cài đặt

### Bước 1 — Copy project
Copy toàn bộ thư mục này vào `htdocs` (XAMPP) hoặc thư mục web root của bạn,
ví dụ: `htdocs/de4/`.

### Bước 2 — Tạo database
Mở phpMyAdmin, chạy file `database.sql`. File này sẽ tạo:
- Database `mmasv_examphp1`
- Bảng `the_loai` (có sẵn 3 thể loại: Tiểu thuyết, Khoa học, Lịch sử)
- Bảng `sach` (có sẵn 2 cuốn sách mẫu)
- Bảng `users` (chưa có tài khoản — tạo ở bước 3)

### Bước 3 — Tạo tài khoản đăng nhập
Truy cập trình duyệt:
```
http://localhost/de4/seed_user.php?mssv=PH37123
```
(Thay `PH37123` bằng MSSV thật nếu cần. Theo đề: username = password = MSSV).

Sau khi thấy "Tạo tài khoản thành công", **xóa file `seed_user.php`**.

### Bước 4 — Chạy thử
```
http://localhost/de4/
```
Trang chủ sẽ hiển thị ngay danh sách sách theo đúng yêu cầu đề bài.

## 3. Đối chiếu với yêu cầu đề 4

| Yêu cầu | Điểm | File xử lý |
|---|---|---|
| Hiển thị danh sách sách (id_sach, ten_sach, tac_gia, nam_xuat_ban, nha_xuat_ban, ten_the_loai) + nút thêm/sửa/xóa | 3đ | `SachController::index()`, `views/sach/list.php` |
| Thêm mới sách, thể loại lấy từ DB vào combobox | 2đ | `SachController::create()/store()`, `views/sach/form.php` |
| + Upload hình ảnh khi thêm sách | 0.5đ | `helper.php::upload_file()`, gọi trong `store()` |
| Sửa thông tin sách, thể loại hiển thị đúng trong combobox | 2đ | `SachController::edit()/update()`, biến `$selectedTheLoaiId` trong `form.php` |
| Xóa sách - có confirm | 1đ | `views/sach/list.php` (`onclick="return confirm(...)"`) |
| Đăng nhập dùng SESSION, chặn các chức năng nếu chưa đăng nhập, hiển thị tên người đăng nhập | 1đ | `AuthController`, `helper.php::require_login()`, `views/main.php` (navbar) |

## 4. Cập nhật mới nhất & lưu ý khi báo cáo / bảo vệ bài

- **Validate năm xuất bản**: không được lớn hơn năm hiện tại. Kiểm tra ở cả
  client-side (`max="<?= date('Y') ?>"` trong input) và server-side
  (`SachController::validate()`, so sánh `(int) $data['nam_xuat_ban'] > (int) date('Y')`).
- **Giao diện đã đổi theme**: chuyển từ Bootstrap mặc định (xanh dương, navbar
  light) sang theme tông xanh teal đậm (`#0d6e5f`), font **Poppins** (Google
  Fonts), navbar dark với gradient, layout dạng `panel-box` bo góc 14px thay
  cho khung `card` mặc định, bảng dùng `table-hover` thay `table-striped`.
  Toàn bộ class CSS tùy biến nằm trong `<style>` của `views/main.php`.
  Mục đích: tránh trùng giao diện hoàn toàn với bài làm khác dùng cùng
  cấu trúc code, nhưng **logic và chức năng không thay đổi**.


- **Giữ ảnh cũ khi sửa**: trong `SachController::update()`, biến
  `$data['hinh_anh']` được gán **trước** bằng `$current['hinh_anh']`
  (lấy từ DB), chỉ ghi đè nếu người dùng có chọn file ảnh mới
  (`$_FILES['hinh_anh']['name']` không rỗng).
- **Combobox hiển thị đúng thể loại khi sửa**: so sánh
  `(string) $selectedClassId === (string) $theLoai['id_the_loai']` để tự
  động gắn `selected` cho đúng option (tránh lỗi so sánh kiểu dữ liệu
  int/string giữa giá trị lấy từ DB và từ HTML).
- **Chặn chức năng khi chưa đăng nhập**: tất cả các action
  `create/store/edit/update/delete` của `SachController` đều gọi
  `require_login()` ngay dòng đầu tiên — nếu `$_SESSION['user']` rỗng sẽ
  tự động redirect về trang đăng nhập.
- **Hiển thị tên người đăng nhập**: lấy từ `$_SESSION['user']['username']`,
  hiển thị ở `views/main.php` (phần navbar) — chỉ hiện khi `is_logged_in()`
  trả về true.
