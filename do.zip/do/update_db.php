<?php
require_once './configs/env.php';

try {
    // Kết nối không chỉ định dbname trước để tránh lỗi "Unknown database"
    $dsnNoDb = sprintf('mysql:host=%s;port=%s;charset=utf8', DB_HOST, DB_PORT);
    $pdo = new PDO($dsnNoDb, DB_USERNAME, DB_PASSWORD, DB_OPTIONS);

    // Tạo Database nếu chưa có
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo " - Đã tạo/kiểm tra Database: <b>" . DB_NAME . "</b><br>";

    // Kết nối vào Database vừa tạo
    $pdo->exec("USE `" . DB_NAME . "`");

    // Tạo các bảng cơ bản nếu chưa có (từ database.sql gốc)
    $pdo->exec("CREATE TABLE IF NOT EXISTS the_loai (
        id_the_loai   INT AUTO_INCREMENT PRIMARY KEY,
        ten_the_loai  VARCHAR(100) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS sach (
        id_sach       INT AUTO_INCREMENT PRIMARY KEY,
        ten_sach      VARCHAR(150) NOT NULL,
        tac_gia       VARCHAR(100) NULL,
        nam_xuat_ban  YEAR NULL,
        nha_xuat_ban  VARCHAR(150) NULL,
        hinh_anh      VARCHAR(255) NULL DEFAULT NULL,
        id_the_loai   INT NULL,
        CONSTRAINT fk_sach_the_loai
            FOREIGN KEY (id_the_loai) REFERENCES the_loai(id_the_loai)
            ON DELETE SET NULL
            ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        user_id  INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Thêm các thể loại mẫu nếu bảng thể loại trống
    $countTheLoai = $pdo->query("SELECT COUNT(*) FROM the_loai")->fetchColumn();
    if ($countTheLoai == 0) {
        $pdo->exec("INSERT INTO the_loai (ten_the_loai) VALUES ('Tiểu thuyết'), ('Khoa học'), ('Lịch sử')");
        echo " - Đã thêm dữ liệu thể loại mẫu.<br>";
    }

    // Thêm sách mẫu nếu bảng sách trống
    $countSach = $pdo->query("SELECT COUNT(*) FROM sach")->fetchColumn();
    if ($countSach == 0) {
        $pdo->exec("INSERT INTO sach (ten_sach, tac_gia, nam_xuat_ban, nha_xuat_ban, hinh_anh, id_the_loai) VALUES
            ('Số đỏ', 'Vũ Trọng Phụng', 1936, 'NXB Văn học', NULL, 1),
            ('Lược sử thời gian', 'Stephen Hawking', 1988, 'NXB Trẻ', NULL, 2)");
        echo " - Đã thêm dữ liệu sách mẫu.<br>";
    }

    echo "<h3>Bắt đầu cập nhật các trường mở rộng...</h3>";

    // 1. Cập nhật bảng users
    $checkUserCols = $pdo->query("SHOW COLUMNS FROM users");
    $userCols = $checkUserCols->fetchAll(PDO::FETCH_COLUMN);

    if (!in_array('ho_ten', $userCols)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN ho_ten VARCHAR(100) NULL AFTER password");
        echo " - Đã thêm cột 'ho_ten' vào bảng 'users'.<br>";
    }
    if (!in_array('email', $userCols)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN email VARCHAR(100) NULL AFTER ho_ten");
        echo " - Đã thêm cột 'email' vào bảng 'users'.<br>";
    }
    if (!in_array('so_dien_thoai', $userCols)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN so_dien_thoai VARCHAR(20) NULL AFTER email");
        echo " - Đã thêm cột 'so_dien_thoai' vào bảng 'users'.<br>";
    }
    if (!in_array('role', $userCols)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user' AFTER so_dien_thoai");
        echo " - Đã thêm cột 'role' vào bảng 'users'.<br>";
    }

    // 2. Cập nhật bảng sach
    $checkSachCols = $pdo->query("SHOW COLUMNS FROM sach");
    $sachCols = $checkSachCols->fetchAll(PDO::FETCH_COLUMN);

    if (!in_array('mo_ta', $sachCols)) {
        $pdo->exec("ALTER TABLE sach ADD COLUMN mo_ta TEXT NULL AFTER hinh_anh");
        echo " - Đã thêm cột 'mo_ta' vào bảng 'sach'.<br>";
    }
    if (!in_array('gia', $sachCols)) {
        $pdo->exec("ALTER TABLE sach ADD COLUMN gia INT DEFAULT 0 AFTER mo_ta");
        echo " - Đã thêm cột 'gia' vào bảng 'sach'.<br>";
    }
    if (!in_array('so_luong', $sachCols)) {
        $pdo->exec("ALTER TABLE sach ADD COLUMN so_luong INT DEFAULT 0 AFTER gia");
        echo " - Đã thêm cột 'so_luong' vào bảng 'sach'.<br>";
    }

    // 3. Tạo bảng binh_luan
    $pdo->exec("CREATE TABLE IF NOT EXISTS binh_luan (
        id_binh_luan INT AUTO_INCREMENT PRIMARY KEY,
        id_sach INT NOT NULL,
        user_id INT NOT NULL,
        noi_dung TEXT NOT NULL,
        ngay_binh_luan DATETIME DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_binh_luan_sach FOREIGN KEY (id_sach) REFERENCES sach(id_sach) ON DELETE CASCADE,
        CONSTRAINT fk_binh_luan_users FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    echo " - Đã tạo/kiểm tra bảng 'binh_luan'.<br>";

    // 4. Tạo tài khoản admin mặc định hoặc cập nhật nếu đã có
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = 'admin'");
    $stmt->execute();
    $adminUser = $stmt->fetch();
    $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
    if (!$adminUser) {
        $stmtInsert = $pdo->prepare("INSERT INTO users (username, password, ho_ten, email, so_dien_thoai, role) 
                                     VALUES ('admin', :password, 'Quản trị viên', 'admin@gmail.com', '0987654321', 'admin')");
        $stmtInsert->execute(['password' => $hashedPassword]);
        echo " - Đã tạo tài khoản admin mặc định: <b>admin</b> / email: <b>admin@gmail.com</b> / mật khẩu: <b>123456</b>.<br>";
    } else {
        $stmtUpdate = $pdo->prepare("UPDATE users SET password = :password, email = 'admin@gmail.com', role = 'admin' WHERE username = 'admin'");
        $stmtUpdate->execute(['password' => $hashedPassword]);
        echo " - Đã cập nhật tài khoản admin: email: <b>admin@gmail.com</b> / mật khẩu: <b>123456</b>.<br>";
    }

    echo "<h3 style='color: green;'>Cập nhật cơ sở dữ liệu thành công!</h3>";
    echo "<p><a href='./index.php'>Quay về trang chủ</a></p>";

} catch (PDOException $e) {
    echo "<h3 style='color: red;'>Lỗi cập nhật CSDL: " . $e->getMessage() . "</h3>";
}
