<?php

if (!function_exists('debug')) {
    function debug($data)
    {
        echo '<pre>';
        print_r($data);
        die;
    }
}

if (!function_exists('upload_file')) {
    function upload_file($folder, $file)
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Lỗi upload: mã lỗi ' . $file['error']);
        }

        $destDir = PATH_ASSETS_UPLOADS . $folder;

        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }

        $filename   = time() . '-' . basename($file['name']);
        $targetFile = $folder . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $destDir . '/' . $filename)) {
            return $targetFile;
        }

        throw new Exception('Upload file không thành công!');
    }
}

/**
 * Kiểm tra người dùng đã đăng nhập chưa, nếu chưa thì chuyển về trang login.
 */
if (!function_exists('require_login')) {
    function require_login()
    {
        if (empty($_SESSION['user'])) {
            header('Location: ' . BASE_URL . 'index.php?action=login');
            exit;
        }
    }
}

if (!function_exists('is_logged_in')) {
    function is_logged_in()
    {
        return !empty($_SESSION['user']);
    }
}

/**
 * Helper redirect ngắn gọn.
 */
if (!function_exists('redirect')) {
    function redirect($action, $params = [])
    {
        $query = array_merge(['action' => $action], $params);
        header('Location: ' . BASE_URL . 'index.php?' . http_build_query($query));
        exit;
    }
}

/**
 * Helper escape HTML để chống XSS khi in dữ liệu ra view.
 */
if (!function_exists('e')) {
    function e($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('is_admin')) {
    function is_admin()
    {
        return is_logged_in() && isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin';
    }
}

if (!function_exists('require_admin')) {
    function require_admin()
    {
        require_login();
        if (!is_admin()) {
            $_SESSION['error'] = 'Bạn không có quyền truy cập vào chức năng này!';
            header('Location: ' . BASE_URL . 'index.php');
            exit;
        }
    }
}

