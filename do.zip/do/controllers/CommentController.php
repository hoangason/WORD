<?php

class CommentController
{
    private $commentModel;

    public function __construct()
    {
        $this->commentModel = new Comment();
    }

    /**
     * Lưu bình luận mới của người dùng.
     */
    public function store()
    {
        if (!is_logged_in()) {
            $_SESSION['login_error'] = 'Bạn cần đăng nhập để viết bình luận.';
            redirect('login');
        }

        $idSach  = $_POST['id_sach'] ?? null;
        $noiDung = trim($_POST['noi_dung'] ?? '');

        if (!$idSach) {
            redirect('/');
        }

        if (empty($noiDung)) {
            $_SESSION['comment_error'] = 'Nội dung bình luận không được để trống.';
            redirect('sach-detail', ['id' => $idSach]);
        }

        $userId = $_SESSION['user']['user_id'];
        $this->commentModel->create($idSach, $userId, $noiDung);

        $_SESSION['comment_success'] = 'Gửi bình luận của bạn thành công!';
        redirect('sach-detail', ['id' => $idSach]);
    }
}
