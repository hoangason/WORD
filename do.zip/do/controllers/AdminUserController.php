<?php

class AdminUserController
{
    private $userModel;

    public function __construct()
    {
        require_admin(); // Chỉ admin mới vào được
        $this->userModel = new User();
    }

    /**
     * Danh sách tài khoản người dùng.
     */
    public function index()
    {
        $users = $this->userModel->getAll();

        $title   = 'Quản lý người dùng';
        $view    = 'admin/user_list';
        $success = $_SESSION['success'] ?? null;
        $error   = $_SESSION['error'] ?? null;
        unset($_SESSION['success'], $_SESSION['error']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Form thêm người dùng mới.
     */
    public function create()
    {
        $title  = 'Thêm người dùng mới';
        $view   = 'admin/user_form';
        $user   = null; // Thêm mới
        $errors = $_SESSION['errors'] ?? [];
        $old    = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý lưu người dùng mới.
     */
    public function store()
    {
        $username       = trim($_POST['username'] ?? '');
        $password       = $_POST['password'] ?? '';
        $ho_ten         = trim($_POST['ho_ten'] ?? '');
        $email          = trim($_POST['email'] ?? '');
        $so_dien_thoai  = trim($_POST['so_dien_thoai'] ?? '');
        $role           = $_POST['role'] ?? 'user';

        $errors = [];

        if (empty($username)) {
            $errors['username'] = 'Tên đăng nhập không được trống.';
        } else {
            if ($this->userModel->findByUsername($username)) {
                $errors['username'] = 'Tên đăng nhập đã tồn tại.';
            }
        }

        if (empty($password)) {
            $errors['password'] = 'Mật khẩu không được trống.';
        }

        if (empty($ho_ten)) {
            $errors['ho_ten'] = 'Họ tên không được trống.';
        }

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old']    = $_POST;
            redirect('admin-users-create');
        }

        $this->userModel->register([
            'username'      => $username,
            'password'      => $password,
            'ho_ten'        => $ho_ten,
            'email'         => $email,
            'so_dien_thoai' => $so_dien_thoai,
            'role'          => $role
        ]);

        $_SESSION['success'] = 'Thêm tài khoản thành công!';
        redirect('admin-users');
    }

    /**
     * Form sửa thông tin người dùng.
     */
    public function edit()
    {
        $userId = $_GET['id'] ?? null;
        $user   = $this->userModel->find($userId);

        if (!$user) {
            $_SESSION['error'] = 'Không tìm thấy người dùng.';
            redirect('admin-users');
        }

        $title  = 'Chỉnh sửa thông tin tài khoản';
        $view   = 'admin/user_form';
        $errors = $_SESSION['errors'] ?? [];
        $old    = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý cập nhật thông tin người dùng.
     */
    public function update()
    {
        $userId        = $_POST['user_id'] ?? null;
        $ho_ten        = trim($_POST['ho_ten'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $so_dien_thoai = trim($_POST['so_dien_thoai'] ?? '');
        $role          = $_POST['role'] ?? 'user';
        $newPassword   = $_POST['new_password'] ?? '';

        $errors = [];

        if (empty($ho_ten)) {
            $errors['ho_ten'] = 'Họ tên không được trống.';
        }

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            redirect('admin-users-edit', ['id' => $userId]);
        }

        $this->userModel->update($userId, [
            'ho_ten'        => $ho_ten,
            'email'         => $email,
            'so_dien_thoai' => $so_dien_thoai,
            'role'          => $role
        ]);

        // Nếu admin muốn đổi luôn mật khẩu cho user
        if (!empty($newPassword)) {
            $this->userModel->updatePassword($userId, $newPassword);
        }

        $_SESSION['success'] = 'Cập nhật tài khoản thành công!';
        redirect('admin-users');
    }

    /**
     * Xóa người dùng.
     */
    public function delete()
    {
        $userId = $_GET['id'] ?? null;
        
        // Không cho phép admin tự xóa chính mình
        if ($userId == $_SESSION['user']['user_id']) {
            $_SESSION['error'] = 'Bạn không thể tự xóa tài khoản của chính mình!';
            redirect('admin-users');
        }

        $user = $this->userModel->find($userId);

        if ($user) {
            $this->userModel->delete($userId);
            $_SESSION['success'] = 'Đã xóa người dùng thành công!';
        } else {
            $_SESSION['error'] = 'Không tìm thấy người dùng để xóa.';
        }

        redirect('admin-users');
    }
}
