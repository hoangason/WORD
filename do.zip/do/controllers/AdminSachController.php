<?php

class AdminSachController
{
    private $sachModel;
    private $theLoaiModel;

    public function __construct()
    {
        require_admin(); // Chỉ admin mới được vào quản lý
        $this->sachModel    = new Sach();
        $this->theLoaiModel = new TheLoai();
    }

    /**
     * Danh sách sách của admin.
     */
    public function index()
    {
        $sachs = $this->sachModel->getAll();

        $title   = 'Quản lý sách';
        $view    = 'admin/sach_list';
        $success = $_SESSION['success'] ?? null;
        $error   = $_SESSION['error'] ?? null;
        unset($_SESSION['success'], $_SESSION['error']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Form thêm mới sách.
     */
    public function create()
    {
        $theLoais = $this->theLoaiModel->getAll();
        $errors   = $_SESSION['errors'] ?? [];
        $old      = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        $sach  = null; // Thêm mới
        $title = 'Thêm sách mới';
        $view  = 'admin/sach_form';

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý lưu sách mới.
     */
    public function store()
    {
        $data   = $this->getFormData();
        $errors = $this->validate($data);

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old']    = $_POST;
            redirect('admin-sach-create');
        }

        // Xử lý upload hình ảnh
        $data['hinh_anh'] = null;
        if (!empty($_FILES['hinh_anh']['name'])) {
            try {
                $data['hinh_anh'] = upload_file('sach', $_FILES['hinh_anh']);
            } catch (Exception $e) {
                $_SESSION['errors'] = ['hinh_anh' => $e->getMessage()];
                $_SESSION['old']    = $_POST;
                redirect('admin-sach-create');
            }
        }

        $this->sachModel->create($data);

        $_SESSION['success'] = 'Thêm mới sách thành công!';
        redirect('admin-sach');
    }

    /**
     * Form chỉnh sửa thông tin sách.
     */
    public function edit()
    {
        $idSach = $_GET['id'] ?? null;
        $sach   = $this->sachModel->find($idSach);

        if (!$sach) {
            $_SESSION['error'] = 'Không tìm thấy sách cần sửa.';
            redirect('admin-sach');
        }

        $theLoais = $this->theLoaiModel->getAll();
        $errors   = $_SESSION['errors'] ?? [];
        $old      = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        $title = 'Chỉnh sửa thông tin sách';
        $view  = 'admin/sach_form';

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý cập nhật thông tin sách.
     */
    public function update()
    {
        $idSach  = $_POST['id_sach'] ?? null;
        $current = $this->sachModel->find($idSach);

        if (!$current) {
            $_SESSION['error'] = 'Không tìm thấy sách cần cập nhật.';
            redirect('admin-sach');
        }

        $data   = $this->getFormData();
        $errors = $this->validate($data);

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old']    = $_POST;
            redirect('admin-sach-edit', ['id' => $idSach]);
        }

        // Giữ lại ảnh cũ nếu không chọn ảnh mới
        $data['hinh_anh'] = $current['hinh_anh'];
        if (!empty($_FILES['hinh_anh']['name'])) {
            try {
                $data['hinh_anh'] = upload_file('sach', $_FILES['hinh_anh']);
            } catch (Exception $e) {
                $_SESSION['errors'] = ['hinh_anh' => $e->getMessage()];
                $_SESSION['old']    = $_POST;
                redirect('admin-sach-edit', ['id' => $idSach]);
            }
        }

        $this->sachModel->update($idSach, $data);

        $_SESSION['success'] = 'Cập nhật thông tin sách thành công!';
        redirect('admin-sach');
    }

    /**
     * Xóa sách.
     */
    public function delete()
    {
        $idSach = $_GET['id'] ?? null;
        $sach   = $this->sachModel->find($idSach);

        if ($sach) {
            $this->sachModel->delete($idSach);
            $_SESSION['success'] = 'Đã xóa sách thành công!';
        } else {
            $_SESSION['error'] = 'Không tìm thấy sách để xóa.';
        }

        redirect('admin-sach');
    }

    /**
     * Lấy thông tin form.
     */
    private function getFormData()
    {
        return [
            'ten_sach'     => trim($_POST['ten_sach'] ?? ''),
            'tac_gia'      => trim($_POST['tac_gia'] ?? ''),
            'nam_xuat_ban' => trim($_POST['nam_xuat_ban'] ?? ''),
            'nha_xuat_ban' => trim($_POST['nha_xuat_ban'] ?? ''),
            'mo_ta'        => trim($_POST['mo_ta'] ?? ''),
            'gia'          => (int) ($_POST['gia'] ?? 0),
            'so_luong'     => (int) ($_POST['so_luong'] ?? 0),
            'id_the_loai'  => $_POST['id_the_loai'] ?? null,
        ];
    }

    /**
     * Validate dữ liệu.
     */
    private function validate($data)
    {
        $errors = [];

        if (empty($data['ten_sach'])) {
            $errors['ten_sach'] = 'Tên sách là bắt buộc.';
        }

        if (!empty($data['nam_xuat_ban'])) {
            if (!preg_match('/^\d{4}$/', $data['nam_xuat_ban'])) {
                $errors['nam_xuat_ban'] = 'Năm xuất bản phải là 4 chữ số.';
            } elseif ((int) $data['nam_xuat_ban'] > (int) date('Y')) {
                $errors['nam_xuat_ban'] = 'Năm xuất bản không được lớn hơn năm hiện tại (' . date('Y') . ').';
            }
        }

        if ($data['gia'] < 0) {
            $errors['gia'] = 'Giá sách không được âm.';
        }

        if ($data['so_luong'] < 0) {
            $errors['so_luong'] = 'Số lượng không được âm.';
        }

        return $errors;
    }
}
