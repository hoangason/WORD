<?php

class UserController
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    /**
     * Hiển thị thông tin cá nhân.
     */
    public function profile()
    {
        require_login();

        $userId = $_SESSION['user']['user_id'];
        $user   = $this->userModel->find($userId);

        if (!$user) {
            $_SESSION['error'] = 'Không tìm thấy thông tin người dùng.';
            redirect('/');
        }

        $title   = 'Thông tin cá nhân';
        $view    = 'user/profile';
        $errors  = $_SESSION['profile_errors'] ?? [];
        $success = $_SESSION['profile_success'] ?? null;
        unset($_SESSION['profile_errors'], $_SESSION['profile_success']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý cập nhật thông tin cá nhân.
     */
    public function updateProfile()
    {
        require_login();

        $userId        = $_SESSION['user']['user_id'];
        $ho_ten        = trim($_POST['ho_ten'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $so_dien_thoai = trim($_POST['so_dien_thoai'] ?? '');

        $errors = [];
        if (empty($ho_ten)) {
            $errors['ho_ten'] = 'Họ tên không được để trống.';
        }

        if (!empty($errors)) {
            $_SESSION['profile_errors'] = $errors;
            redirect('profile');
        }

        // Lấy thông tin user hiện tại để giữ nguyên quyền (role)
        $currentUser = $this->userModel->find($userId);

        $data = [
            'ho_ten'        => $ho_ten,
            'email'         => $email,
            'so_dien_thoai' => $so_dien_thoai,
            'role'          => $currentUser['role']
        ];

        $this->userModel->update($userId, $data);

        // Cập nhật lại session
        $_SESSION['user']['ho_ten']        = $ho_ten;
        $_SESSION['user']['email']         = $email;
        $_SESSION['user']['so_dien_thoai'] = $so_dien_thoai;

        $_SESSION['profile_success'] = 'Cập nhật thông tin cá nhân thành công!';
        redirect('profile');
    }

    /**
     * Hiển thị form đổi mật khẩu.
     */
    public function changePassword()
    {
        require_login();

        $title   = 'Đổi mật khẩu';
        $view    = 'user/change_password';
        $errors  = $_SESSION['password_errors'] ?? [];
        $success = $_SESSION['password_success'] ?? null;
        unset($_SESSION['password_errors'], $_SESSION['password_success']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý đổi mật khẩu.
     */
    public function doChangePassword()
    {
        require_login();

        $userId          = $_SESSION['user']['user_id'];
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword     = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        $errors = [];

        $user = $this->userModel->find($userId);

        if (!password_verify($currentPassword, $user['password'])) {
            $errors['current_password'] = 'Mật khẩu hiện tại không chính xác.';
        }

        if (empty($newPassword)) {
            $errors['new_password'] = 'Mật khẩu mới không được để trống.';
        } elseif (strlen($newPassword) < 4) {
            $errors['new_password'] = 'Mật khẩu mới phải dài ít nhất 4 ký tự.';
        }

        if ($newPassword !== $confirmPassword) {
            $errors['confirm_password'] = 'Xác nhận mật khẩu mới không trùng khớp.';
        }

        if (!empty($errors)) {
            $_SESSION['password_errors'] = $errors;
            redirect('change-password');
        }

        $this->userModel->updatePassword($userId, $newPassword);

        $_SESSION['password_success'] = 'Đổi mật khẩu thành công!';
        redirect('change-password');
    }
}
