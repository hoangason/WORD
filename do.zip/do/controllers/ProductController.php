<?php

class ProductController
{
    private $sachModel;
    private $theLoaiModel;
    private $commentModel;

    public function __construct()
    {
        $this->sachModel    = new Sach();
        $this->theLoaiModel = new TheLoai();
        $this->commentModel = new Comment();
    }

    /**
     * Hiển thị danh sách sản phẩm (sách) dạng lưới, hỗ trợ tìm kiếm và lọc.
     */
    public function index()
    {
        $idTheLoai = $_GET['id_the_loai'] ?? null;
        $keyword   = trim($_GET['keyword'] ?? '');

        // Lấy sách sau khi lọc/tìm kiếm
        $sachs = $this->sachModel->searchAndFilter($idTheLoai, $keyword);
        
        // Lấy danh sách danh mục để lọc
        $theLoais = $this->theLoaiModel->getAll();

        $selectedCategoryName = '';
        if ($idTheLoai) {
            $cat = $this->theLoaiModel->find($idTheLoai);
            if ($cat) {
                $selectedCategoryName = $cat['ten_the_loai'];
            }
        }

        $title = 'Danh mục sách';
        $view  = 'product/list';

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Hiển thị chi tiết sách và bình luận.
     */
    public function detail()
    {
        $idSach = $_GET['id'] ?? null;
        $sach   = $this->sachModel->find($idSach);

        if (!$sach) {
            $_SESSION['error'] = 'Không tìm thấy cuốn sách này.';
            redirect('san-pham');
        }

        // Lấy các bình luận của cuốn sách
        $comments = $this->commentModel->getBySach($idSach);

        $title = $sach['ten_sach'];
        $view  = 'product/detail';

        $comment_success = $_SESSION['comment_success'] ?? null;
        $comment_error   = $_SESSION['comment_error'] ?? null;
        unset($_SESSION['comment_success'], $_SESSION['comment_error']);

        require_once PATH_VIEW_MAIN;
    }
}
