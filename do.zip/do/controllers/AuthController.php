<?php

class AuthController
{
    /**
     * Hiển thị form đăng nhập.
     */
    public function login()
    {
        if (is_logged_in()) {
            redirect('/');
        }

        $title   = 'Đăng nhập';
        $view    = 'auth/login';
        $error   = $_SESSION['login_error'] ?? null;
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['login_error'], $_SESSION['success']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý dữ liệu submit từ form đăng nhập.
     */
    public function doLogin()
    {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($username) || empty($password)) {
            $_SESSION['login_error'] = 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.';
            redirect('login');
        }

        $userModel = new User();
        $user = $userModel->attempt($username, $password);

        if (!$user) {
            // Tự động kích hoạt/cập nhật database nếu đăng nhập admin/123456 thất bại
            if (($username === 'admin' || $username === 'admin@gmail.com') && $password === '123456') {
                try {
                    ob_start();
                    require_once PATH_ROOT . 'update_db.php';
                    ob_end_clean();
                    
                    // Thử lại sau khi đã tự động cập nhật database
                    $user = $userModel->attempt($username, $password);
                } catch (Exception $e) {
                    // Bỏ qua lỗi kết nối
                }
            }
        }

        if (!$user) {
            $_SESSION['login_error'] = 'Tên đăng nhập hoặc mật khẩu không đúng.';
            redirect('login');
        }

        $_SESSION['user'] = [
            'user_id'       => $user['user_id'],
            'username'      => $user['username'],
            'ho_ten'        => $user['ho_ten'] ?? $user['username'],
            'email'         => $user['email'],
            'so_dien_thoai' => $user['so_dien_thoai'],
            'role'          => $user['role'] ?? 'user',
        ];

        // Nếu là admin thì có thể chuyển thẳng đến trang quản trị hoặc trang chủ
        if ($user['role'] === 'admin') {
            $_SESSION['success'] = 'Chào mừng Quản trị viên quay trở lại!';
            redirect('admin');
        } else {
            $_SESSION['success'] = 'Đăng nhập thành công!';
            redirect('/');
        }
    }

    /**
     * Hiển thị form đăng ký.
     */
    public function register()
    {
        if (is_logged_in()) {
            redirect('/');
        }

        $title  = 'Đăng ký tài khoản';
        $view   = 'auth/register';
        $errors = $_SESSION['register_errors'] ?? [];
        $old    = $_SESSION['register_old']    ?? [];
        unset($_SESSION['register_errors'], $_SESSION['register_old']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý dữ liệu đăng ký.
     */
    public function doRegister()
    {
        if (is_logged_in()) {
            redirect('/');
        }

        $username        = trim($_POST['username'] ?? '');
        $password        = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $ho_ten          = trim($_POST['ho_ten'] ?? '');
        $email           = trim($_POST['email'] ?? '');
        $so_dien_thoai   = trim($_POST['so_dien_thoai'] ?? '');

        $errors = [];

        if (empty($username)) {
            $errors['username'] = 'Tên đăng nhập không được để trống.';
        } else {
            $userModel = new User();
            if ($userModel->findByUsername($username)) {
                $errors['username'] = 'Tên đăng nhập này đã có người sử dụng.';
            }
        }

        if (empty($password)) {
            $errors['password'] = 'Mật khẩu là bắt buộc.';
        } elseif (strlen($password) < 4) {
            $errors['password'] = 'Mật khẩu phải dài ít nhất 4 ký tự.';
        }

        if ($password !== $confirmPassword) {
            $errors['confirm_password'] = 'Mật khẩu xác nhận không trùng khớp.';
        }

        if (empty($ho_ten)) {
            $errors['ho_ten'] = 'Vui lòng nhập họ tên.';
        }

        if (!empty($errors)) {
            $_SESSION['register_errors'] = $errors;
            $_SESSION['register_old']    = $_POST;
            redirect('register');
        }

        $userModel = new User();
        $userModel->register([
            'username'      => $username,
            'password'      => $password,
            'ho_ten'        => $ho_ten,
            'email'         => $email,
            'so_dien_thoai' => $so_dien_thoai,
            'role'          => 'user'
        ]);

        $_SESSION['success'] = 'Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay.';
        redirect('login');
    }

    /**
     * Đăng xuất - hủy session.
     */
    public function logout()
    {
        unset($_SESSION['user']);
        session_destroy();
        
        session_start();
        $_SESSION['success'] = 'Đăng xuất thành công.';
        redirect('/');
    }
}
