<?php

class AdminTheLoaiController
{
    private $theLoaiModel;

    public function __construct()
    {
        require_admin(); // Chỉ admin mới được truy cập
        $this->theLoaiModel = new TheLoai();
    }

    /**
     * Danh sách thể loại.
     */
    public function index()
    {
        $theLoais = $this->theLoaiModel->getAll();

        $title   = 'Quản lý danh mục thể loại';
        $view    = 'admin/theloai_list';
        $success = $_SESSION['success'] ?? null;
        $error   = $_SESSION['error'] ?? null;
        unset($_SESSION['success'], $_SESSION['error']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Form thêm mới thể loại.
     */
    public function create()
    {
        $title = 'Thêm danh mục mới';
        $view  = 'admin/theloai_form';
        $theLoai = null;

        $errors = $_SESSION['errors'] ?? [];
        $old    = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý lưu thể loại.
     */
    public function store()
    {
        $tenTheLoai = trim($_POST['ten_the_loai'] ?? '');

        if (empty($tenTheLoai)) {
            $_SESSION['errors'] = ['ten_the_loai' => 'Tên danh mục không được để trống.'];
            $_SESSION['old']    = $_POST;
            redirect('admin-theloai-create');
        }

        $this->theLoaiModel->create($tenTheLoai);

        $_SESSION['success'] = 'Thêm danh mục thể loại thành công!';
        redirect('admin-theloai');
    }

    /**
     * Form sửa thể loại.
     */
    public function edit()
    {
        $idTheLoai = $_GET['id'] ?? null;
        $theLoai   = $this->theLoaiModel->find($idTheLoai);

        if (!$theLoai) {
            $_SESSION['error'] = 'Không tìm thấy danh mục thể loại.';
            redirect('admin-theloai');
        }

        $title = 'Chỉnh sửa danh mục';
        $view  = 'admin/theloai_form';

        $errors = $_SESSION['errors'] ?? [];
        $old    = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý cập nhật thể loại.
     */
    public function update()
    {
        $idTheLoai  = $_POST['id_the_loai'] ?? null;
        $tenTheLoai = trim($_POST['ten_the_loai'] ?? '');

        if (empty($tenTheLoai)) {
            $_SESSION['errors'] = ['ten_the_loai' => 'Tên danh mục không được để trống.'];
            $_SESSION['old']    = $_POST;
            redirect('admin-theloai-edit', ['id' => $idTheLoai]);
        }

        $this->theLoaiModel->update($idTheLoai, $tenTheLoai);

        $_SESSION['success'] = 'Cập nhật danh mục thể loại thành công!';
        redirect('admin-theloai');
    }

    /**
     * Xóa thể loại.
     */
    public function delete()
    {
        $idTheLoai = $_GET['id'] ?? null;
        $theLoai   = $this->theLoaiModel->find($idTheLoai);

        if ($theLoai) {
            try {
                $this->theLoaiModel->delete($idTheLoai);
                $_SESSION['success'] = 'Đã xóa danh mục thể loại thành công!';
            } catch (Exception $e) {
                $_SESSION['error'] = 'Không thể xóa danh mục này vì đang có sách tham chiếu thuộc danh mục.';
            }
        } else {
            $_SESSION['error'] = 'Không tìm thấy danh mục để xóa.';
        }

        redirect('admin-theloai');
    }
}
