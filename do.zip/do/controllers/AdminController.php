<?php

class AdminController extends BaseModel
{
    private $sachModel;
    private $theLoaiModel;
    private $userModel;
    private $commentModel;

    public function __construct()
    {
        parent::__construct();
        require_admin(); // Đảm bảo chỉ có Admin mới vào được

        $this->sachModel    = new Sach();
        $this->theLoaiModel = new TheLoai();
        $this->userModel    = new User();
        $this->commentModel = new Comment();
    }

    /**
     * Ý 4.5: Báo cáo và thống kê + Dashboard
     */
    public function dashboard()
    {
        // 1. Thống kê tổng số lượng
        $totalBooks      = count($this->sachModel->getAll());
        $totalCategories = count($this->theLoaiModel->getAll());
        $totalUsers      = count($this->userModel->getAll());
        $totalComments   = $this->commentModel->countAll();

        // 2. Thống kê sách theo danh mục (Cơ cấu danh mục)
        $sqlStats = "SELECT tl.ten_the_loai, COUNT(s.id_sach) as sach_count
                     FROM the_loai tl
                     LEFT JOIN sach s ON tl.id_the_loai = s.id_the_loai
                     GROUP BY tl.id_the_loai, tl.ten_the_loai
                     ORDER BY sach_count DESC";
        $categoryStats = $this->pdo->query($sqlStats)->fetchAll();

        // 3. Lấy 8 bình luận mới nhất để quản lý nhanh
        $recentComments = $this->commentModel->getAllRecent(8);

        $title = 'Báo cáo & Thống kê';
        $view  = 'admin/dashboard';
        
        $success = $_SESSION['success'] ?? null;
        $error   = $_SESSION['error'] ?? null;
        unset($_SESSION['success'], $_SESSION['error']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xóa bình luận trái phép/không phù hợp từ Dashboard
     */
    public function deleteComment()
    {
        $idComment = $_GET['id'] ?? null;
        if ($idComment) {
            $this->commentModel->delete($idComment);
            $_SESSION['success'] = 'Đã xóa bình luận thành công!';
        } else {
            $_SESSION['error'] = 'Không xác định được bình luận cần xóa.';
        }
        redirect('admin-dashboard');
    }
}
