<?php

class SachController
{
    private $sachModel;
    private $theLoaiModel;

    public function __construct()
    {
        $this->sachModel    = new Sach();
        $this->theLoaiModel = new TheLoai();
    }

    /**
     * 1. (3 điểm) Hiển thị danh sách sách:
     * id_sach, ten_sach, tac_gia, nam_xuat_ban, nha_xuat_ban, ten_the_loai
     * Có nút thêm mới, nút sửa và xóa cho từng cuốn sách.
     */
    public function index()
    {
        $sachs = $this->sachModel->getAll();

        $title   = 'Danh sách sách';
        $view    = 'sach/list';
        $success = $_SESSION['success'] ?? null;
        unset($_SESSION['success']);

        require_once PATH_VIEW_MAIN;
    }

    /**
     * 2. (2.5 điểm) Hiển thị form thêm mới sách.
     * Thể loại sách lấy từ bảng the_loai cho vào combobox.
     */
    public function create()
    {
        require_login();

        $theLoais = $this->theLoaiModel->getAll();
        $errors   = $_SESSION['errors'] ?? [];
        $old      = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        $sach  = null; // chế độ thêm mới
        $title = 'Thêm mới sách';
        $view  = 'sach/form';

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý lưu dữ liệu thêm mới sách (+ upload hình ảnh, 0.5 điểm).
     */
    public function store()
    {
        require_login();

        $data   = $this->getFormData();
        $errors = $this->validate($data);

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old']    = $_POST;
            redirect('sach-create');
        }

        // hinh_anh mặc định null nếu không upload ảnh
        $data['hinh_anh'] = null;
        if (!empty($_FILES['hinh_anh']['name'])) {
            try {
                $data['hinh_anh'] = upload_file('sach', $_FILES['hinh_anh']);
            } catch (Exception $e) {
                $_SESSION['errors'] = ['hinh_anh' => $e->getMessage()];
                $_SESSION['old']    = $_POST;
                redirect('sach-create');
            }
        }

        $this->sachModel->create($data);

        $_SESSION['success'] = 'Thêm mới sách thành công!';
        redirect('/');
    }

    /**
     * 3. (2 điểm) Hiển thị form chỉnh sửa thông tin sách.
     * Thể loại phải hiển thị chính xác trong combobox (đã chọn sẵn).
     */
    public function edit()
    {
        require_login();

        $idSach = $_GET['id'] ?? null;
        $sach   = $this->sachModel->find($idSach);

        if (!$sach) {
            $_SESSION['success'] = 'Không tìm thấy sách.';
            redirect('/');
        }

        $theLoais = $this->theLoaiModel->getAll();
        $errors   = $_SESSION['errors'] ?? [];
        $old      = $_SESSION['old']    ?? [];
        unset($_SESSION['errors'], $_SESSION['old']);

        $title = 'Chỉnh sửa thông tin sách';
        $view  = 'sach/form';

        require_once PATH_VIEW_MAIN;
    }

    /**
     * Xử lý lưu dữ liệu chỉnh sửa sách.
     * Nếu không chọn ảnh mới -> giữ lại ảnh cũ.
     */
    public function update()
    {
        require_login();

        $idSach  = $_POST['id_sach'] ?? null;
        $current = $this->sachModel->find($idSach);

        if (!$current) {
            $_SESSION['success'] = 'Không tìm thấy sách.';
            redirect('/');
        }

        $data   = $this->getFormData();
        $errors = $this->validate($data);

        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            $_SESSION['old']    = $_POST;
            redirect('sach-edit', ['id' => $idSach]);
        }

        // Giữ lại ảnh cũ nếu không upload ảnh mới
        $data['hinh_anh'] = $current['hinh_anh'];
        if (!empty($_FILES['hinh_anh']['name'])) {
            try {
                $data['hinh_anh'] = upload_file('sach', $_FILES['hinh_anh']);
            } catch (Exception $e) {
                $_SESSION['errors'] = ['hinh_anh' => $e->getMessage()];
                $_SESSION['old']    = $_POST;
                redirect('sach-edit', ['id' => $idSach]);
            }
        }

        $this->sachModel->update($idSach, $data);

        $_SESSION['success'] = 'Cập nhật thông tin sách thành công!';
        redirect('/');
    }

    /**
     * 4. (1 điểm) Xóa sách - có confirm (xử lý ở phía view bằng JS confirm()).
     */
    public function delete()
    {
        require_login();

        $idSach = $_GET['id'] ?? null;
        $sach   = $this->sachModel->find($idSach);

        if ($sach) {
            $this->sachModel->delete($idSach);
            $_SESSION['success'] = 'Đã xóa sách thành công!';
        }

        redirect('/');
    }

    /**
     * Lấy dữ liệu từ form (POST) thành mảng chuẩn để lưu DB.
     */
    private function getFormData()
    {
        return [
            'ten_sach'     => trim($_POST['ten_sach'] ?? ''),
            'tac_gia'      => trim($_POST['tac_gia'] ?? ''),
            'nam_xuat_ban' => trim($_POST['nam_xuat_ban'] ?? ''),
            'nha_xuat_ban' => trim($_POST['nha_xuat_ban'] ?? ''),
            'id_the_loai'  => $_POST['id_the_loai'] ?? null,
        ];
    }

    /**
     * Validate dữ liệu cơ bản (đề không yêu cầu chi tiết, chỉ cần các
     * trường bắt buộc tối thiểu để dữ liệu hợp lệ).
     */
    private function validate($data)
    {
        $errors = [];

        if (empty($data['ten_sach'])) {
            $errors['ten_sach'] = 'Tên sách là bắt buộc.';
        }

        if (!empty($data['nam_xuat_ban'])) {
            if (!preg_match('/^\d{4}$/', $data['nam_xuat_ban'])) {
                $errors['nam_xuat_ban'] = 'Năm xuất bản phải là 4 chữ số.';
            } elseif ((int) $data['nam_xuat_ban'] > (int) date('Y')) {
                $errors['nam_xuat_ban'] = 'Năm xuất bản không được lớn hơn năm hiện tại (' . date('Y') . ').';
            }
        }

        return $errors;
    }
}
