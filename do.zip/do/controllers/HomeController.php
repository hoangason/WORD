<?php

class HomeController
{
    private $sachModel;
    private $theLoaiModel;

    public function __construct()
    {
        $this->sachModel    = new Sach();
        $this->theLoaiModel = new TheLoai();
    }

    public function index()
    {
        // Lấy tất cả danh mục
        $theLoais = $this->theLoaiModel->getAll();
        
        // Lấy danh sách sách
        $allSachs = $this->sachModel->getAll();
        
        // Lấy 4 cuốn sách mới nhất làm nổi bật
        $featuredSachs = array_slice($allSachs, 0, 4);

        $title = 'Trang chủ';
        $view  = 'home';

        require_once PATH_VIEW_MAIN;
    }
}
