<?php

$action = $_GET['action'] ?? '/';

match ($action) {
    '/'                     => (new HomeController())->index(),
    'home'                  => (new HomeController())->index(),

    // Auth
    'login'                 => (new AuthController())->login(),
    'do-login'              => (new AuthController())->doLogin(),
    'logout'                => (new AuthController())->logout(),
    'register'              => (new AuthController())->register(),
    'do-register'           => (new AuthController())->doRegister(),

    // User settings
    'profile'               => (new UserController())->profile(),
    'update-profile'        => (new UserController())->updateProfile(),
    'change-password'       => (new UserController())->changePassword(),
    'do-change-password'    => (new UserController())->doChangePassword(),

    // Client Product list & Detail
    'san-pham'              => (new ProductController())->index(),
    'sach-detail'           => (new ProductController())->detail(),

    // Comments
    'comment-store'         => (new CommentController())->store(),

    // Admin Dashboard
    'admin'                 => (new AdminController())->dashboard(),
    'admin-dashboard'       => (new AdminController())->dashboard(),
    'admin-comment-delete'  => (new AdminController())->deleteComment(),

    // Admin TheLoai CRUD
    'admin-theloai'         => (new AdminTheLoaiController())->index(),
    'admin-theloai-create'  => (new AdminTheLoaiController())->create(),
    'admin-theloai-store'   => (new AdminTheLoaiController())->store(),
    'admin-theloai-edit'    => (new AdminTheLoaiController())->edit(),
    'admin-theloai-update'  => (new AdminTheLoaiController())->update(),
    'admin-theloai-delete'  => (new AdminTheLoaiController())->delete(),

    // Admin Sach CRUD
    'admin-sach'            => (new AdminSachController())->index(),
    'admin-sach-create'     => (new AdminSachController())->create(),
    'admin-sach-store'      => (new AdminSachController())->store(),
    'admin-sach-edit'       => (new AdminSachController())->edit(),
    'admin-sach-update'     => (new AdminSachController())->update(),
    'admin-sach-delete'     => (new AdminSachController())->delete(),

    // Admin User CRUD
    'admin-users'           => (new AdminUserController())->index(),
    'admin-users-create'    => (new AdminUserController())->create(),
    'admin-users-store'     => (new AdminUserController())->store(),
    'admin-users-edit'      => (new AdminUserController())->edit(),
    'admin-users-update'    => (new AdminUserController())->update(),
    'admin-users-delete'    => (new AdminUserController())->delete(),

    // Fallback Sach Controller (Original CRUD)
    'sach-create'           => (new SachController())->create(),
    'sach-store'            => (new SachController())->store(),
    'sach-edit'             => (new SachController())->edit(),
    'sach-update'           => (new SachController())->update(),
    'sach-delete'           => (new SachController())->delete(),

    default                 => (new HomeController())->index(),
};
