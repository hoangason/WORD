<?php

class User extends BaseModel
{
    protected $table = 'users';

    /**
     * Tìm user theo username.
     */
    public function findByUsername($username)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE username = :username OR email = :username");
        $stmt->execute(['username' => $username]);
        return $stmt->fetch();
    }

    /**
     * Kiểm tra đăng nhập: username = MSSV, password = MSSV.
     * Trả về thông tin user nếu đúng, false nếu sai.
     */
    public function attempt($username, $password)
    {
        $user = $this->findByUsername($username);

        if (!$user) {
            return false;
        }

        if (!password_verify($password, $user['password'])) {
            return false;
        }

        return $user;
    }

    /**
     * Lấy danh sách tất cả người dùng.
     */
    public function getAll()
    {
        $stmt = $this->pdo->query("SELECT * FROM {$this->table} ORDER BY user_id DESC");
        return $stmt->fetchAll();
    }

    /**
     * Tìm người dùng theo ID.
     */
    public function find($userId)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetch();
    }

    /**
     * Đăng ký người dùng mới.
     */
    public function register($data)
    {
        $sql = "INSERT INTO {$this->table} (username, password, ho_ten, email, so_dien_thoai, role) 
                VALUES (:username, :password, :ho_ten, :email, :so_dien_thoai, :role)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'username'      => $data['username'],
            'password'      => password_hash($data['password'], PASSWORD_DEFAULT),
            'ho_ten'        => $data['ho_ten'],
            'email'         => $data['email'],
            'so_dien_thoai' => $data['so_dien_thoai'],
            'role'          => $data['role'] ?? 'user'
        ]);
    }

    /**
     * Cập nhật thông tin cá nhân.
     */
    public function update($userId, $data)
    {
        $sql = "UPDATE {$this->table} SET 
                    ho_ten = :ho_ten, 
                    email = :email, 
                    so_dien_thoai = :so_dien_thoai,
                    role = :role
                WHERE user_id = :user_id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'ho_ten'        => $data['ho_ten'],
            'email'         => $data['email'],
            'so_dien_thoai' => $data['so_dien_thoai'],
            'role'          => $data['role'] ?? 'user',
            'user_id'       => $userId
        ]);
    }

    /**
     * Đổi mật khẩu.
     */
    public function updatePassword($userId, $newPassword)
    {
        $sql = "UPDATE {$this->table} SET password = :password WHERE user_id = :user_id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'password' => password_hash($newPassword, PASSWORD_DEFAULT),
            'user_id'  => $userId
        ]);
    }

    /**
     * Xóa người dùng.
     */
    public function delete($userId)
    {
        $stmt = $this->pdo->prepare("DELETE FROM {$this->table} WHERE user_id = :user_id");
        return $stmt->execute(['user_id' => $userId]);
    }
}

