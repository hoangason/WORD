<?php

class Sach extends BaseModel
{
    protected $table = 'sach';

    /**
     * Lấy danh sách sách kèm tên thể loại (JOIN bảng the_loai).
     */
    public function getAll()
    {
        $sql = "SELECT s.*, tl.ten_the_loai
                FROM {$this->table} s
                LEFT JOIN the_loai tl ON s.id_the_loai = tl.id_the_loai
                ORDER BY s.id_sach DESC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * Lấy thông tin 1 cuốn sách theo id (kèm tên thể loại).
     */
    public function find($idSach)
    {
        $sql = "SELECT s.*, tl.ten_the_loai
                FROM {$this->table} s
                LEFT JOIN the_loai tl ON s.id_the_loai = tl.id_the_loai
                WHERE s.id_sach = :id_sach";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id_sach' => $idSach]);
        return $stmt->fetch();
    }

    /**
     * Thêm mới sách. hinh_anh mặc định là null nếu không upload.
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table}
                    (ten_sach, tac_gia, nam_xuat_ban, nha_xuat_ban, hinh_anh, mo_ta, gia, so_luong, id_the_loai)
                VALUES
                    (:ten_sach, :tac_gia, :nam_xuat_ban, :nha_xuat_ban, :hinh_anh, :mo_ta, :gia, :so_luong, :id_the_loai)";

        $stmt = $this->pdo->prepare($sql);

        return $stmt->execute([
            'ten_sach'     => $data['ten_sach'],
            'tac_gia'      => $data['tac_gia'],
            'nam_xuat_ban' => $data['nam_xuat_ban'],
            'nha_xuat_ban' => $data['nha_xuat_ban'],
            'hinh_anh'     => $data['hinh_anh'],
            'mo_ta'        => $data['mo_ta'] ?? null,
            'gia'          => $data['gia'] ?? 0,
            'so_luong'     => $data['so_luong'] ?? 0,
            'id_the_loai'  => $data['id_the_loai'],
        ]);
    }

    /**
     * Cập nhật thông tin sách.
     * $data['hinh_anh'] có thể giữ ảnh cũ nếu không upload ảnh mới
     */
    public function update($idSach, $data)
    {
        $sql = "UPDATE {$this->table} SET
                    ten_sach     = :ten_sach,
                    tac_gia      = :tac_gia,
                    nam_xuat_ban = :nam_xuat_ban,
                    nha_xuat_ban = :nha_xuat_ban,
                    hinh_anh     = :hinh_anh,
                    mo_ta        = :mo_ta,
                    gia          = :gia,
                    so_luong     = :so_luong,
                    id_the_loai  = :id_the_loai
                WHERE id_sach = :id_sach";

        $stmt = $this->pdo->prepare($sql);

        return $stmt->execute([
            'ten_sach'     => $data['ten_sach'],
            'tac_gia'      => $data['tac_gia'],
            'nam_xuat_ban' => $data['nam_xuat_ban'],
            'nha_xuat_ban' => $data['nha_xuat_ban'],
            'hinh_anh'     => $data['hinh_anh'],
            'mo_ta'        => $data['mo_ta'] ?? null,
            'gia'          => $data['gia'] ?? 0,
            'so_luong'     => $data['so_luong'] ?? 0,
            'id_the_loai'  => $data['id_the_loai'],
            'id_sach'      => $idSach,
        ]);
    }

    /**
     * Xóa sách theo id.
     */
    public function delete($idSach)
    {
        $stmt = $this->pdo->prepare("DELETE FROM {$this->table} WHERE id_sach = :id_sach");
        return $stmt->execute(['id_sach' => $idSach]);
    }

    /**
     * Tìm kiếm và lọc sách.
     */
    public function searchAndFilter($idTheLoai = null, $keyword = '')
    {
        $sql = "SELECT s.*, tl.ten_the_loai
                FROM {$this->table} s
                LEFT JOIN the_loai tl ON s.id_the_loai = tl.id_the_loai
                WHERE 1=1";
        
        $params = [];

        if (!empty($idTheLoai)) {
            $sql .= " AND s.id_the_loai = :id_the_loai";
            $params['id_the_loai'] = $idTheLoai;
        }

        if (!empty($keyword)) {
            $sql .= " AND (s.ten_sach LIKE :keyword OR s.tac_gia LIKE :keyword OR s.nha_xuat_ban LIKE :keyword)";
            $params['keyword'] = '%' . $keyword . '%';
        }

        $sql .= " ORDER BY s.id_sach DESC";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}

