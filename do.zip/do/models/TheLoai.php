<?php

class TheLoai extends BaseModel
{
    protected $table = 'the_loai';

    /**
     * Lấy toàn bộ danh sách thể loại (dùng đổ vào combobox).
     */
    public function getAll()
    {
        $stmt = $this->pdo->query("SELECT * FROM {$this->table} ORDER BY ten_the_loai ASC");
        return $stmt->fetchAll();
    }

    public function find($idTheLoai)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE id_the_loai = :id_the_loai");
        $stmt->execute(['id_the_loai' => $idTheLoai]);
        return $stmt->fetch();
    }

    /**
     * Thêm mới thể loại.
     */
    public function create($tenTheLoai)
    {
        $stmt = $this->pdo->prepare("INSERT INTO {$this->table} (ten_the_loai) VALUES (:ten_the_loai)");
        return $stmt->execute(['ten_the_loai' => $tenTheLoai]);
    }

    /**
     * Cập nhật thể loại.
     */
    public function update($idTheLoai, $tenTheLoai)
    {
        $stmt = $this->pdo->prepare("UPDATE {$this->table} SET ten_the_loai = :ten_the_loai WHERE id_the_loai = :id_the_loai");
        return $stmt->execute(['ten_the_loai' => $tenTheLoai, 'id_the_loai' => $idTheLoai]);
    }

    /**
     * Xóa thể loại.
     */
    public function delete($idTheLoai)
    {
        $stmt = $this->pdo->prepare("DELETE FROM {$this->table} WHERE id_the_loai = :id_the_loai");
        return $stmt->execute(['id_the_loai' => $idTheLoai]);
    }
}

