<?php

class Comment extends BaseModel
{
    protected $table = 'binh_luan';

    /**
     * Lấy danh sách bình luận của một cuốn sách kèm tên người bình luận.
     */
    public function getBySach($idSach)
    {
        $sql = "SELECT bl.*, u.username, u.ho_ten 
                FROM {$this->table} bl
                JOIN users u ON bl.user_id = u.user_id
                WHERE bl.id_sach = :id_sach
                ORDER BY bl.ngay_binh_luan DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id_sach' => $idSach]);
        return $stmt->fetchAll();
    }

    /**
     * Thêm bình luận mới.
     */
    public function create($idSach, $userId, $noiDung)
    {
        $sql = "INSERT INTO {$this->table} (id_sach, user_id, noi_dung, ngay_binh_luan) 
                VALUES (:id_sach, :user_id, :noi_dung, NOW())";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            'id_sach'  => $idSach,
            'user_id'  => $userId,
            'noi_dung' => $noiDung
        ]);
    }

    /**
     * Lấy các bình luận mới nhất (dành cho Admin dashboard).
     */
    public function getAllRecent($limit = 5)
    {
        $sql = "SELECT bl.*, u.username, u.ho_ten, s.ten_sach 
                FROM {$this->table} bl
                JOIN users u ON bl.user_id = u.user_id
                JOIN sach s ON bl.id_sach = s.id_sach
                ORDER BY bl.ngay_binh_luan DESC
                LIMIT :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Xóa bình luận.
     */
    public function delete($idComment)
    {
        $stmt = $this->pdo->prepare("DELETE FROM {$this->table} WHERE id_binh_luan = :id_binh_luan");
        return $stmt->execute(['id_binh_luan' => $idComment]);
    }

    /**
     * Đếm tổng số bình luận.
     */
    public function countAll()
    {
        return $this->pdo->query("SELECT COUNT(*) FROM {$this->table}")->fetchColumn();
    }
}
