<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Trang chủ' ?> | Thư viện sách</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome for beautiful icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --brand-color: #0d6e5f;
            --brand-color-dark: #094f44;
            --brand-color-light: #e6f2f0;
            --brand-accent: #f2a541;
            --text-dark: #2c3e50;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8faf9;
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .topbar {
            background: linear-gradient(135deg, var(--brand-color-dark), var(--brand-color));
            box-shadow: 0 4px 12px rgba(13, 110, 95, 0.15);
            padding: 0.8rem 0;
        }

        .topbar .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
            color: #ffffff !important;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .topbar .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .topbar .nav-link:hover,
        .topbar .nav-item.active .nav-link {
            color: #ffffff !important;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .topbar .dropdown-menu {
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
            padding: 0.5rem 0;
        }

        .topbar .dropdown-item {
            font-weight: 500;
            padding: 0.6rem 1.5rem;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .topbar .dropdown-item:hover {
            background-color: var(--brand-color-light);
            color: var(--brand-color-dark);
        }

        .page-wrapper {
            flex: 1;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            padding: 2.5rem 1rem 4rem;
        }

        .page-heading {
            font-weight: 700;
            color: var(--brand-color-dark);
            border-left: 6px solid var(--brand-accent);
            padding-left: 0.75rem;
            margin-bottom: 2rem;
            font-size: 1.8rem;
        }

        .btn-brand {
            background-color: var(--brand-color);
            border-color: var(--brand-color);
            color: #fff;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-brand:hover {
            background-color: var(--brand-color-dark);
            border-color: var(--brand-color-dark);
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(13, 110, 95, 0.2);
        }

        .btn-outline-brand {
            border-color: var(--brand-color);
            color: var(--brand-color);
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-outline-brand:hover {
            background-color: var(--brand-color);
            color: #fff;
            transform: translateY(-2px);
        }

        .panel-box {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.04);
            padding: 2rem;
            border: 1px solid rgba(13, 110, 95, 0.05);
        }

        .card-product {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            background: #fff;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .card-product:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 25px rgba(13, 110, 95, 0.12);
        }

        .card-product-img {
            position: relative;
            padding-top: 130%; /* 4:3 Aspect Ratio for covers */
            background-color: #f1f5f3;
            overflow: hidden;
        }

        .card-product-img img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .card-product:hover .card-product-img img {
            transform: scale(1.08);
        }

        .card-product-body {
            padding: 1.25rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .card-product-title {
            font-size: 1.05rem;
            font-weight: 600;
            color: var(--brand-color-dark);
            margin-bottom: 0.4rem;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            height: 2.8rem;
        }

        .card-product-author {
            font-size: 0.88rem;
            color: #7f8c8d;
            margin-bottom: 0.5rem;
        }

        .card-product-price {
            font-size: 1.15rem;
            font-weight: 700;
            color: #e74c3c;
            margin-top: auto;
        }

        .app-footer {
            background-color: #1e2d2b;
            color: #bdc3c7;
            padding: 3rem 0 1.5rem;
            margin-top: auto;
            border-top: 4px solid var(--brand-color);
        }

        .app-footer h5 {
            color: #ffffff;
            font-weight: 600;
            margin-bottom: 1.2rem;
        }

        .footer-link {
            color: #bdc3c7;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .footer-link:hover {
            color: var(--brand-accent);
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg topbar navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= BASE_URL ?>">
                <i class="fa-solid fa-book-open"></i> Thư viện sách
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" 
                    aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-3 gap-2">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>"><i class="fa-solid fa-house me-1"></i> Trang chủ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>?action=san-pham"><i class="fa-solid fa-book me-1"></i> Sản phẩm</a>
                    </li>
                </ul>
                
                <div class="d-flex align-items-center gap-3">
                    <?php if (is_logged_in()): ?>
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-white d-flex align-items-center gap-2 fw-semibold" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="bg-white text-dark rounded-circle d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
                                    <i class="fa-solid fa-user"></i>
                                </div>
                                <?= e($_SESSION['user']['ho_ten'] ?? $_SESSION['user']['username']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow">
                                <li>
                                    <div class="px-3 py-2 text-muted border-bottom mb-1" style="font-size: 0.85rem;">
                                        Quyền: <span class="badge text-bg-<?= is_admin() ? 'danger' : 'success' ?>"><?= is_admin() ? 'Quản trị viên' : 'Khách hàng' ?></span>
                                    </div>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= BASE_URL ?>?action=profile">
                                        <i class="fa-solid fa-id-card"></i> Thông tin cá nhân
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?= BASE_URL ?>?action=change-password">
                                        <i class="fa-solid fa-key"></i> Đổi mật khẩu
                                    </a>
                                </li>
                                
                                <?php if (is_admin()): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger fw-semibold" href="<?= BASE_URL ?>?action=admin">
                                            <i class="fa-solid fa-gauge-high"></i> Trang quản trị
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="<?= BASE_URL ?>?action=logout">
                                        <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>?action=login" class="nav-link"><i class="fa-solid fa-right-to-bracket me-1"></i> Đăng nhập</a>
                        <a href="<?= BASE_URL ?>?action=register" class="btn btn-warning fw-semibold px-3"><i class="fa-solid fa-user-plus me-1"></i> Đăng ký</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="page-wrapper">
        
        <!-- Alerts -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4 rounded-3" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?= e($_SESSION['success']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm mb-4 rounded-3" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> <?= e($_SESSION['error']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <h2 class="page-heading"><?= $title ?? 'Trang chủ' ?></h2>

        <?php
        if (isset($view)) {
            require_once PATH_VIEW . $view . '.php';
        }
        ?>
    </div>

    <footer class="app-footer">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-5">
                    <h5>📚 Thư viện sách MVC</h5>
                    <p class="small">Dự án mẫu nâng cấp phục vụ học tập và quản lý sách. Hệ thống được viết trên nền tảng PHP MVC, hỗ trợ phân quyền và giao diện tối ưu hóa trải nghiệm người dùng.</p>
                </div>
                <div class="col-md-3 offset-md-1">
                    <h5>Liên kết nhanh</h5>
                    <ul class="list-unstyled small d-flex flex-column gap-2">
                        <li><a href="<?= BASE_URL ?>" class="footer-link">Trang chủ</a></li>
                        <li><a href="<?= BASE_URL ?>?action=san-pham" class="footer-link">Danh sách sách</a></li>
                        <?php if (is_logged_in()): ?>
                            <li><a href="<?= BASE_URL ?>?action=profile" class="footer-link">Tài khoản</a></li>
                        <?php else: ?>
                            <li><a href="<?= BASE_URL ?>?action=login" class="footer-link">Đăng nhập</a></li>
                            <li><a href="<?= BASE_URL ?>?action=register" class="footer-link">Đăng ký thành viên</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Thông tin nhóm</h5>
                    <p class="small mb-1"><i class="fa-solid fa-users me-2"></i> Nhóm N4 - Dự án mẫu</p>
                    <p class="small mb-1"><i class="fa-solid fa-envelope me-2"></i> support@library.com</p>
                    <p class="small"><i class="fa-solid fa-phone me-2"></i> +84 987 654 321</p>
                </div>
            </div>
            <hr class="border-secondary mt-4 mb-3">
            <div class="row">
                <div class="col-md-6 small text-center text-md-start">
                    &copy; <?= date('Y') ?> Thư viện sách MVC. Tất cả các quyền được bảo lưu.
                </div>
                <div class="col-md-6 small text-center text-md-end mt-2 mt-md-0">
                    Phát triển với <i class="fa-solid fa-heart text-danger"></i> dành cho TKTW
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
