<!-- Hero Section -->
<div class="p-5 mb-5 rounded-4 text-white" style="background: linear-gradient(135deg, #094f44 0%, #16a085 100%); position: relative; overflow: hidden;">
    <div style="position: absolute; right: -50px; bottom: -50px; opacity: 0.1; font-size: 15rem;">
        <i class="fa-solid fa-book-open"></i>
    </div>
    <div class="row align-items-center py-4">
        <div class="col-lg-7">
            <h1 class="display-5 fw-bold mb-3">Tìm kiếm kho tàng tri thức bạn yêu thích</h1>
            <p class="lead mb-4">Khám phá hàng ngàn cuốn sách thuộc nhiều thể loại khác nhau. Đăng ký tài khoản để gửi nhận xét, bình luận và theo dõi những tác phẩm mới nhất.</p>
            
            <!-- Search Form -->
            <form action="<?= BASE_URL ?>" method="GET" class="d-flex bg-white p-2 rounded-3 shadow">
                <input type="hidden" name="action" value="san-pham">
                <div class="input-group">
                    <span class="input-group-text bg-white border-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" name="keyword" class="form-control border-0 bg-white" placeholder="Tìm tên sách, tác giả, nhà xuất bản..." required>
                    <button class="btn btn-brand" type="submit">Tìm kiếm</button>
                </div>
            </form>
        </div>
        <div class="col-lg-5 d-none d-lg-block text-center">
            <img src="https://img.freepik.com/free-vector/flat-world-book-day-illustration_23-2148875323.jpg" alt="Library illustration" class="img-fluid rounded-4 shadow-sm" style="max-height: 280px; object-fit: cover;">
        </div>
    </div>
</div>

<!-- Danh mục thể loại -->
<div class="mb-5">
    <h3 class="fw-bold mb-4 text-dark d-flex align-items-center gap-2">
        <i class="fa-solid fa-list text-success"></i> Khám phá theo danh mục
    </h3>
    <div class="row g-3">
        <?php foreach ($theLoais as $theLoai): ?>
            <div class="col-md-4">
                <a href="<?= BASE_URL ?>?action=san-pham&id_the_loai=<?= $theLoai['id_the_loai'] ?>" class="text-decoration-none text-dark">
                    <div class="card border-0 p-4 shadow-sm rounded-3 hover-shadow transition" style="background-color: #ffffff; border-left: 5px solid var(--brand-color) !important;">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <h5 class="fw-bold mb-1"><?= e($theLoai['ten_the_loai']) ?></h5>
                                <span class="text-muted small">Xem các cuốn sách thuộc danh mục</span>
                            </div>
                            <div class="text-success fs-4">
                                <i class="fa-solid fa-circle-chevron-right"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Sách mới nhất -->
<div>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
            <i class="fa-solid fa-clock text-success"></i> Sách mới cập nhật
        </h3>
        <a href="<?= BASE_URL ?>?action=san-pham" class="btn btn-outline-brand btn-sm">Xem tất cả <i class="fa-solid fa-arrow-right"></i></a>
    </div>

    <div class="row g-4">
        <?php if (empty($featuredSachs)): ?>
            <div class="col-12 text-center text-muted py-5">
                Chưa có dữ liệu sách.
            </div>
        <?php else: ?>
            <?php foreach ($featuredSachs as $sach): ?>
                <div class="col-sm-6 col-md-4 col-lg-3">
                    <div class="card-product">
                        <div class="card-product-img">
                            <?php if (!empty($sach['hinh_anh'])): ?>
                                <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt="<?= e($sach['ten_sach']) ?>">
                            <?php else: ?>
                                <div class="d-flex flex-column align-items-center justify-content-center h-100 bg-light text-muted p-3">
                                    <i class="fa-solid fa-book fs-1 mb-2"></i>
                                    <span class="small">Chưa có ảnh bìa</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-product-body">
                            <span class="badge rounded-pill text-bg-light border mb-2 me-auto"><?= e($sach['ten_the_loai'] ?? 'Chưa phân loại') ?></span>
                            <h5 class="card-product-title" title="<?= e($sach['ten_sach']) ?>">
                                <a href="<?= BASE_URL ?>?action=sach-detail&id=<?= $sach['id_sach'] ?>" class="text-decoration-none text-dark">
                                    <?= e($sach['ten_sach']) ?>
                                </a>
                            </h5>
                            <p class="card-product-author mb-1">Tác giả: <strong><?= e($sach['tac_gia'] ?: 'Chưa rõ') ?></strong></p>
                            <p class="small text-muted mb-2">Năm XB: <?= e($sach['nam_xuat_ban'] ?: 'Chưa cập nhật') ?></p>
                            
                            <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                <span class="card-product-price text-danger fw-bold">
                                    <?= !empty($sach['gia']) ? number_format($sach['gia']) . ' đ' : 'Liên hệ' ?>
                                </span>
                                <a href="<?= BASE_URL ?>?action=sach-detail&id=<?= $sach['id_sach'] ?>" class="btn btn-sm btn-brand">Chi tiết</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
    .hover-shadow {
        transition: all 0.3s ease;
    }
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08) !important;
    }
    .transition {
        transition: all 0.3s ease;
    }
</style>
