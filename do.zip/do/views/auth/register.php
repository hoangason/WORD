<div class="panel-box" style="max-width: 500px; margin: 0 auto;">

    <h4 class="fw-bold mb-4 text-center text-success"><i class="fa-solid fa-user-plus me-2"></i>Đăng ký tài khoản</h4>

    <form action="<?= BASE_URL ?>?action=do-register" method="POST">
        
        <!-- Username (MSSV) -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Tên đăng nhập (MSSV) <span class="text-danger">*</span></label>
            <input type="text" name="username" class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>" 
                   placeholder="VD: PH37123" value="<?= e($old['username'] ?? '') ?>" required>
            <?php if (isset($errors['username'])): ?>
                <div class="invalid-feedback"><?= e($errors['username']) ?></div>
            <?php endif; ?>
        </div>

        <!-- Full Name -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Họ tên <span class="text-danger">*</span></label>
            <input type="text" name="ho_ten" class="form-control <?= isset($errors['ho_ten']) ? 'is-invalid' : '' ?>" 
                   placeholder="Nhập họ và tên đầy đủ" value="<?= e($old['ho_ten'] ?? '') ?>" required>
            <?php if (isset($errors['ho_ten'])): ?>
                <div class="invalid-feedback"><?= e($errors['ho_ten']) ?></div>
            <?php endif; ?>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Địa chỉ Email</label>
            <input type="email" name="email" class="form-control" 
                   placeholder="VD: sv@fpt.edu.vn" value="<?= e($old['email'] ?? '') ?>">
        </div>

        <!-- Phone -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Số điện thoại</label>
            <input type="text" name="so_dien_thoai" class="form-control" 
                   placeholder="VD: 0987654321" value="<?= e($old['so_dien_thoai'] ?? '') ?>">
        </div>

        <!-- Password -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Mật khẩu <span class="text-danger">*</span></label>
            <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                   placeholder="Mật khẩu tối thiểu 4 ký tự" required>
            <?php if (isset($errors['password'])): ?>
                <div class="invalid-feedback"><?= e($errors['password']) ?></div>
            <?php endif; ?>
        </div>

        <!-- Confirm Password -->
        <div class="mb-4">
            <label class="form-label fw-semibold">Xác nhận mật khẩu <span class="text-danger">*</span></label>
            <input type="password" name="confirm_password" class="form-control <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>" 
                   placeholder="Nhập lại mật khẩu" required>
            <?php if (isset($errors['confirm_password'])): ?>
                <div class="invalid-feedback"><?= e($errors['confirm_password']) ?></div>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-brand w-100 mb-3"><i class="fa-solid fa-user-plus me-1"></i> Đăng ký thành viên</button>
        
        <div class="text-center small">
            Đã có tài khoản? <a href="<?= BASE_URL ?>?action=login" class="text-success fw-bold text-decoration-none">Đăng nhập ngay</a>
        </div>
    </form>

</div>
