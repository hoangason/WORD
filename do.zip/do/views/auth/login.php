<div class="panel-box" style="max-width: 420px; margin: 0 auto;">

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php endif; ?>

    <form action="<?= BASE_URL ?>?action=do-login" method="POST">
        <div class="mb-3">
            <label class="form-label fw-semibold">Tên đăng nhập (MSSV)</label>
            <input type="text" name="username" class="form-control" placeholder="VD: PH37123" required>
        </div>

        <div class="mb-4">
            <label class="form-label fw-semibold">Mật khẩu</label>
            <input type="password" name="password" class="form-control" placeholder="Mật khẩu = MSSV" required>
        </div>

        <button type="submit" class="btn btn-brand w-100">Đăng nhập</button>
    </form>

</div>
