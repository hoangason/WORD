<div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="max-width: 750px; margin: 0 auto;">

    <?php
    $isEdit     = isset($sach) && !empty($sach);
    $formAction = $isEdit ? 'admin-sach-update' : 'admin-sach-store';

    $val = function ($field) use ($old, $isEdit, $sach) {
        if (isset($old[$field])) {
            return $old[$field];
        }
        if ($isEdit && isset($sach[$field])) {
            return $sach[$field];
        }
        return '';
    };
    ?>

    <h4 class="fw-bold mb-4 border-bottom pb-2 text-dark">
        <i class="fa-solid fa-book-medical text-success me-2"></i>
        <?= $isEdit ? 'Chỉnh sửa sách #' . e($sach['id_sach']) : 'Thêm sách mới' ?>
    </h4>

    <form action="<?= BASE_URL ?>?action=<?= $formAction ?>" method="POST" enctype="multipart/form-data">

        <?php if ($isEdit): ?>
            <input type="hidden" name="id_sach" value="<?= e($sach['id_sach']) ?>">
        <?php endif; ?>

        <!-- Ten sach -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Tên sách <span class="text-danger">*</span></label>
            <input type="text" name="ten_sach" class="form-control <?= isset($errors['ten_sach']) ? 'is-invalid' : '' ?>"
                   placeholder="Nhập tên sách..." value="<?= e($val('ten_sach')) ?>" required>
            <?php if (isset($errors['ten_sach'])): ?>
                <div class="invalid-feedback"><?= e($errors['ten_sach']) ?></div>
            <?php endif; ?>
        </div>

        <div class="row">
            <!-- Tac gia -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Tác giả</label>
                <input type="text" name="tac_gia" class="form-control" placeholder="Tên tác giả..." value="<?= e($val('tac_gia')) ?>">
            </div>

            <!-- The loai -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Thể loại</label>
                <select name="id_the_loai" class="form-select">
                    <option value="">-- Chọn thể loại --</option>
                    <?php
                    $selectedTheLoaiId = $old['id_the_loai'] ?? ($isEdit ? $sach['id_the_loai'] : null);
                    foreach ($theLoais as $theLoai):
                    ?>
                        <option value="<?= $theLoai['id_the_loai'] ?>"
                            <?= ((string) $selectedTheLoaiId === (string) $theLoai['id_the_loai']) ? 'selected' : '' ?>>
                            <?= e($theLoai['ten_the_loai']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row">
            <!-- Nha xuat ban -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Nhà xuất bản</label>
                <input type="text" name="nha_xuat_ban" class="form-control" placeholder="Nhà xuất bản..." value="<?= e($val('nha_xuat_ban')) ?>">
            </div>

            <!-- Nam xuat ban -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Năm xuất bản</label>
                <input type="number" name="nam_xuat_ban" class="form-control <?= isset($errors['nam_xuat_ban']) ? 'is-invalid' : '' ?>"
                       placeholder="VD: 2020" min="1900" max="<?= date('Y') ?>"
                       value="<?= e($val('nam_xuat_ban')) ?>">
                <?php if (isset($errors['nam_xuat_ban'])): ?>
                    <div class="invalid-feedback"><?= e($errors['nam_xuat_ban']) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <!-- Gia ban -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Giá bán (đ) <span class="text-danger">*</span></label>
                <input type="number" name="gia" class="form-control <?= isset($errors['gia']) ? 'is-invalid' : '' ?>" 
                       placeholder="Nhập giá sách..." min="0" value="<?= (int) $val('gia') ?: 0 ?>" required>
                <?php if (isset($errors['gia'])): ?>
                    <div class="invalid-feedback"><?= e($errors['gia']) ?></div>
                <?php endif; ?>
            </div>

            <!-- So luong -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Số lượng trong kho <span class="text-danger">*</span></label>
                <input type="number" name="so_luong" class="form-control <?= isset($errors['so_luong']) ? 'is-invalid' : '' ?>" 
                       placeholder="Nhập số lượng..." min="0" value="<?= (int) $val('so_luong') ?: 0 ?>" required>
                <?php if (isset($errors['so_luong'])): ?>
                    <div class="invalid-feedback"><?= e($errors['so_luong']) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Mo ta -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Mô tả nội dung</label>
            <textarea name="mo_ta" class="form-control" rows="4" placeholder="Nhập mô tả tóm tắt về cuốn sách..."><?= e($val('mo_ta')) ?></textarea>
        </div>

        <!-- Hinh anh -->
        <div class="mb-4">
            <label class="form-label fw-semibold">Ảnh bìa sách</label>
            <input type="file" name="hinh_anh" class="form-control <?= isset($errors['hinh_anh']) ? 'is-invalid' : '' ?>" accept="image/*">
            <?php if (isset($errors['hinh_anh'])): ?>
                <div class="invalid-feedback"><?= e($errors['hinh_anh']) ?></div>
            <?php endif; ?>

            <?php if ($isEdit && !empty($sach['hinh_anh'])): ?>
                <div class="mt-2 d-flex align-items-center gap-3 bg-light p-2 rounded-2">
                    <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt=""
                         style="width:55px;height:75px;object-fit:cover;border-radius:4px;" class="shadow-sm">
                    <small class="text-muted">Giữ nguyên ảnh cũ nếu không chọn ảnh mới.</small>
                </div>
            <?php endif; ?>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-brand">
                <i class="fa-solid fa-save me-1"></i> <?= $isEdit ? 'Lưu thay đổi' : 'Thêm sách' ?>
            </button>
            <a href="<?= BASE_URL ?>?action=admin-sach" class="btn btn-outline-secondary">Hủy</a>
        </div>

    </form>

</div>
