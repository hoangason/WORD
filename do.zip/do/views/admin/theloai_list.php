<!-- Admin Navigation Submenu -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
            <ul class="nav nav-pills gap-2">
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin">
                        <i class="fa-solid fa-chart-line me-1"></i> Thống kê & Báo cáo
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active bg-success text-white" href="<?= BASE_URL ?>?action=admin-theloai">
                        <i class="fa-solid fa-list me-1"></i> Quản lý thể loại
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-sach">
                        <i class="fa-solid fa-book me-1"></i> Quản lý sách
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-users">
                        <i class="fa-solid fa-users me-1"></i> Quản lý người dùng
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-3 p-4 bg-white">
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
        <h4 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-list text-success me-2"></i>Danh mục thể loại</h4>
        <a href="<?= BASE_URL ?>?action=admin-theloai-create" class="btn btn-brand">
            <i class="fa-solid fa-plus me-1"></i> Thêm thể loại mới
        </a>
    </div>

    <!-- Category Table -->
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr class="table-light">
                    <th style="width: 15%;">Mã danh mục</th>
                    <th>Tên danh mục thể loại</th>
                    <th class="text-center" style="width: 20%;">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($theLoais)): ?>
                    <tr>
                        <td colspan="3" class="text-center text-muted py-4">Chưa có danh mục thể loại nào.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($theLoais as $theLoai): ?>
                        <tr>
                            <td>#<?= e($theLoai['id_the_loai']) ?></td>
                            <td><strong><?= e($theLoai['ten_the_loai']) ?></strong></td>
                            <td class="text-center">
                                <a href="<?= BASE_URL ?>?action=admin-theloai-edit&id=<?= $theLoai['id_the_loai'] ?>" 
                                   class="btn btn-sm btn-outline-secondary me-2">
                                    <i class="fa-regular fa-edit me-1"></i>Sửa
                                </a>
                                <a href="<?= BASE_URL ?>?action=admin-theloai-delete&id=<?= $theLoai['id_the_loai'] ?>" 
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục \'<?= e($theLoai['ten_the_loai']) ?>\'? Tất cả sách thuộc thể loại này sẽ bị hủy phân loại.');">
                                    <i class="fa-regular fa-trash-can me-1"></i>Xóa
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
