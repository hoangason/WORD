<!-- Admin Navigation Submenu -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
            <ul class="nav nav-pills gap-2">
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin">
                        <i class="fa-solid fa-chart-line me-1"></i> Thống kê & Báo cáo
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-theloai">
                        <i class="fa-solid fa-list me-1"></i> Quản lý thể loại
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-sach">
                        <i class="fa-solid fa-book me-1"></i> Quản lý sách
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active bg-success text-white" href="<?= BASE_URL ?>?action=admin-users">
                        <i class="fa-solid fa-users me-1"></i> Quản lý người dùng
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-3 p-4 bg-white">
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
        <h4 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-users text-success me-2"></i>Quản lý người dùng & tài khoản</h4>
        <a href="<?= BASE_URL ?>?action=admin-users-create" class="btn btn-brand">
            <i class="fa-solid fa-user-plus me-1"></i> Tạo tài khoản mới
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr class="table-light">
                    <th>Mã</th>
                    <th>Tên đăng nhập (MSSV)</th>
                    <th>Họ và tên</th>
                    <th>Email</th>
                    <th>Số điện thoại</th>
                    <th>Quyền hạn</th>
                    <th class="text-center" style="width: 15%;">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Chưa có tài khoản người dùng nào.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td>#<?= e($u['user_id']) ?></td>
                            <td><strong><?= e($u['username']) ?></strong></td>
                            <td><?= e($u['ho_ten'] ?: 'Chưa cập nhật') ?></td>
                            <td><?= e($u['email'] ?: 'Chưa có') ?></td>
                            <td><?= e($u['so_dien_thoai'] ?: 'Chưa có') ?></td>
                            <td>
                                <span class="badge text-bg-<?= ($u['role'] === 'admin') ? 'danger' : 'success' ?>">
                                    <?= ($u['role'] === 'admin') ? 'Quản trị viên' : 'Khách hàng' ?>
                                </span>
                            </td>
                            <td class="text-center text-nowrap">
                                <a href="<?= BASE_URL ?>?action=admin-users-edit&id=<?= $u['user_id'] ?>" 
                                   class="btn btn-sm btn-outline-secondary me-1" title="Sửa tài khoản / Đổi mật khẩu">
                                    <i class="fa-regular fa-edit"></i>
                                </a>
                                <?php if ($u['user_id'] != $_SESSION['user']['user_id']): ?>
                                    <a href="<?= BASE_URL ?>?action=admin-users-delete&id=<?= $u['user_id'] ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Bạn có chắc chắn muốn xóa tài khoản người dùng \'<?= e($u['username']) ?>\' không?');">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-outline-danger" disabled title="Tài khoản của bạn" style="opacity: 0.4;">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
