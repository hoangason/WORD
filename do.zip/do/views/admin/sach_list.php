<!-- Admin Navigation Submenu -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
            <ul class="nav nav-pills gap-2">
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin">
                        <i class="fa-solid fa-chart-line me-1"></i> Thống kê & Báo cáo
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-theloai">
                        <i class="fa-solid fa-list me-1"></i> Quản lý thể loại
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active bg-success text-white" href="<?= BASE_URL ?>?action=admin-sach">
                        <i class="fa-solid fa-book me-1"></i> Quản lý sách
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-users">
                        <i class="fa-solid fa-users me-1"></i> Quản lý người dùng
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-3 p-4 bg-white">
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
        <h4 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-book-open text-success me-2"></i>Danh sách sách quản lý</h4>
        <a href="<?= BASE_URL ?>?action=admin-sach-create" class="btn btn-brand">
            <i class="fa-solid fa-plus me-1"></i> Thêm sách mới
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr class="table-light">
                    <th>Mã</th>
                    <th>Ảnh bìa</th>
                    <th>Tên sách</th>
                    <th>Tác giả</th>
                    <th>Thể loại</th>
                    <th class="text-end">Giá bán</th>
                    <th class="text-center">Số lượng</th>
                    <th class="text-center" style="width: 15%;">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($sachs)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">Chưa có dữ liệu sách nào trong thư viện.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($sachs as $sach): ?>
                        <tr>
                            <td>#<?= e($sach['id_sach']) ?></td>
                            <td>
                                <?php if (!empty($sach['hinh_anh'])): ?>
                                    <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt=""
                                         style="width:45px;height:60px;object-fit:cover;border-radius:4px;" class="shadow-sm">
                                <?php else: ?>
                                    <span class="text-muted small">No image</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong class="text-dark d-block"><?= e($sach['ten_sach']) ?></strong>
                                <span class="text-muted small">NXB: <?= e($sach['nha_xuat_ban'] ?: 'Chưa cập nhật') ?> (<?= e($sach['nam_xuat_ban'] ?: 'Chưa rõ') ?>)</span>
                            </td>
                            <td><?= e($sach['tac_gia'] ?: 'Chưa cập nhật') ?></td>
                            <td>
                                <span class="badge rounded-pill text-bg-light border">
                                    <?= e($sach['ten_the_loai'] ?? 'Chưa phân loại') ?>
                                </span>
                            </td>
                            <td class="text-end text-danger fw-bold">
                                <?= !empty($sach['gia']) ? number_format($sach['gia']) . ' đ' : 'Chưa nhập' ?>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-<?= ($sach['so_luong'] > 0) ? 'success' : 'danger' ?>">
                                    <?= $sach['so_luong'] ?> cuốn
                                </span>
                            </td>
                            <td class="text-center text-nowrap">
                                <a href="<?= BASE_URL ?>?action=admin-sach-edit&id=<?= $sach['id_sach'] ?>"
                                   class="btn btn-sm btn-outline-secondary me-1">
                                    <i class="fa-regular fa-edit"></i>
                                </a>
                                <a href="<?= BASE_URL ?>?action=admin-sach-delete&id=<?= $sach['id_sach'] ?>"
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('Bạn có chắc chắn muốn xóa cuốn sách \'<?= e($sach['ten_sach']) ?>\'?');">
                                    <i class="fa-regular fa-trash-can"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
