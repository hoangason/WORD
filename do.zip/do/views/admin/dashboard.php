<?php $admin_active = 'dashboard'; ?>

<!-- Admin Navigation Submenu -->
<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
            <ul class="nav nav-pills gap-2">
                <li class="nav-item">
                    <a class="nav-link active bg-success text-white" href="<?= BASE_URL ?>?action=admin">
                        <i class="fa-solid fa-chart-line me-1"></i> Thống kê & Báo cáo
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-theloai">
                        <i class="fa-solid fa-list me-1"></i> Quản lý thể loại
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-sach">
                        <i class="fa-solid fa-book me-1"></i> Quản lý sách
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="<?= BASE_URL ?>?action=admin-users">
                        <i class="fa-solid fa-users me-1"></i> Quản lý người dùng
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<!-- Stat Cards -->
<div class="row g-4 mb-4">
    
    <!-- Total Books -->
    <div class="col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="border-left: 5px solid #16a085 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small d-block mb-1">Tổng số sách</span>
                    <h2 class="fw-bold mb-0 text-dark"><?= $totalBooks ?></h2>
                </div>
                <div class="fs-1 text-success opacity-50"><i class="fa-solid fa-book"></i></div>
            </div>
        </div>
    </div>

    <!-- Total Categories -->
    <div class="col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="border-left: 5px solid #3498db !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small d-block mb-1">Thể loại</span>
                    <h2 class="fw-bold mb-0 text-dark"><?= $totalCategories ?></h2>
                </div>
                <div class="fs-1 text-primary opacity-50"><i class="fa-solid fa-list"></i></div>
            </div>
        </div>
    </div>

    <!-- Total Users -->
    <div class="col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="border-left: 5px solid #f39c12 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small d-block mb-1">Người dùng</span>
                    <h2 class="fw-bold mb-0 text-dark"><?= $totalUsers ?></h2>
                </div>
                <div class="fs-1 text-warning opacity-50"><i class="fa-solid fa-users"></i></div>
            </div>
        </div>
    </div>

    <!-- Total Comments -->
    <div class="col-sm-6 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="border-left: 5px solid #9b59b6 !important;">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small d-block mb-1">Bình luận</span>
                    <h2 class="fw-bold mb-0 text-dark"><?= $totalComments ?></h2>
                </div>
                <div class="fs-1 text-purple opacity-50" style="color: #9b59b6;"><i class="fa-solid fa-comments"></i></div>
            </div>
        </div>
    </div>
    
</div>

<!-- Detailed Stats & Moderation Section -->
<div class="row g-4">
    
    <!-- Category Breakdown (Ý 4.5) -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white h-100">
            <h5 class="fw-bold mb-4 text-dark"><i class="fa-solid fa-chart-pie text-success me-2"></i>Cơ cấu sách theo thể loại</h5>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr class="table-light">
                            <th>Thể loại</th>
                            <th class="text-center">Số lượng</th>
                            <th>Tỷ lệ cơ cấu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categoryStats)): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted">Chưa có dữ liệu thống kê.</td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            foreach ($categoryStats as $stat): 
                                $percent = $totalBooks > 0 ? round(($stat['sach_count'] / $totalBooks) * 100, 1) : 0;
                            ?>
                                <tr>
                                    <td><strong><?= e($stat['ten_the_loai']) ?></strong></td>
                                    <td class="text-center"><span class="badge bg-light text-dark border"><?= $stat['sach_count'] ?> cuốn</span></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="progress flex-grow-1" style="height: 8px;">
                                                <div class="progress-bar bg-success" role="progressbar" style="width: <?= $percent ?>%" 
                                                     aria-valuenow="<?= $percent ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <span class="small text-muted" style="min-width: 40px;"><?= $percent ?>%</span>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Recent Comments Moderation (Ý 3.3 / Ý 4.5) -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-3 p-4 bg-white h-100">
            <h5 class="fw-bold mb-4 text-dark"><i class="fa-regular fa-comment-dots text-success me-2"></i>Bình luận mới nhất</h5>
            
            <div class="comments-moderation">
                <?php if (empty($recentComments)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="fa-regular fa-comments fs-2 mb-2 text-secondary"></i>
                        <p>Chưa có bình luận nào trên hệ thống.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush" style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($recentComments as $comment): ?>
                            <div class="list-group-item px-0 border-0 mb-3 pb-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <div>
                                        <strong class="text-dark"><?= e($comment['ho_ten'] ?? $comment['username']) ?></strong>
                                        <span class="text-muted small"> bình luận ở bài </span>
                                        <a href="<?= BASE_URL ?>?action=sach-detail&id=<?= $comment['id_sach'] ?>" class="text-success fw-semibold text-decoration-none">
                                            <?= e($comment['ten_sach']) ?>
                                        </a>
                                    </div>
                                    <a href="<?= BASE_URL ?>?action=admin-comment-delete&id=<?= $comment['id_binh_luan'] ?>" 
                                       class="btn btn-sm btn-outline-danger py-0 px-2"
                                       onclick="return confirm('Bạn có chắc chắn muốn xóa bình luận này?');"
                                       title="Xóa bình luận này">
                                        Xóa
                                    </a>
                                </div>
                                <p class="text-secondary small mb-1" style="white-space: pre-line;"><?= e($comment['noi_dung']) ?></p>
                                <div class="text-muted small" style="font-size: 0.78rem;">
                                    <i class="fa-regular fa-clock me-1"></i><?= date('d/m/Y H:i', strtotime($comment['ngay_binh_luan'])) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
    
</div>
