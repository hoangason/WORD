<?php
$isEdit = isset($user) && !empty($user);
$formAction = $isEdit ? 'admin-users-update' : 'admin-users-store';

$val = function ($field) use ($old, $isEdit, $user) {
    if (isset($old[$field])) {
        return $old[$field];
    }
    if ($isEdit && isset($user[$field])) {
        return $user[$field];
    }
    return '';
};
?>

<div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="max-width: 650px; margin: 0 auto;">
    
    <h4 class="fw-bold mb-4 border-bottom pb-2 text-dark">
        <i class="fa-solid fa-user-gear text-success me-2"></i>
        <?= $isEdit ? 'Chỉnh sửa tài khoản #' . e($user['user_id']) : 'Thêm tài khoản người dùng mới' ?>
    </h4>

    <form action="<?= BASE_URL ?>?action=<?= $formAction ?>" method="POST">
        
        <?php if ($isEdit): ?>
            <input type="hidden" name="user_id" value="<?= e($user['user_id']) ?>">
        <?php endif; ?>

        <div class="row">
            <!-- Username -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Tên đăng nhập (MSSV) <span class="text-danger">*</span></label>
                <?php if ($isEdit): ?>
                    <input type="text" class="form-control bg-light" value="<?= e($user['username']) ?>" readonly disabled>
                <?php else: ?>
                    <input type="text" name="username" class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>" 
                           placeholder="VD: PH37123" value="<?= e($val('username')) ?>" required>
                    <?php if (isset($errors['username'])): ?>
                        <div class="invalid-feedback"><?= e($errors['username']) ?></div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Role -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Quyền hạn <span class="text-danger">*</span></label>
                <select name="role" class="form-select">
                    <?php
                    $selectedRole = $old['role'] ?? ($isEdit ? $user['role'] : 'user');
                    ?>
                    <option value="user" <?= ($selectedRole === 'user') ? 'selected' : '' ?>>Khách hàng (User)</option>
                    <option value="admin" <?= ($selectedRole === 'admin') ? 'selected' : '' ?>>Quản trị viên (Admin)</option>
                </select>
            </div>
        </div>

        <!-- Full Name -->
        <div class="mb-3">
            <label class="form-label fw-semibold">Họ tên <span class="text-danger">*</span></label>
            <input type="text" name="ho_ten" class="form-control <?= isset($errors['ho_ten']) ? 'is-invalid' : '' ?>" 
                   placeholder="Nhập họ và tên đầy đủ..." value="<?= e($val('ho_ten')) ?>" required>
            <?php if (isset($errors['ho_ten'])): ?>
                <div class="invalid-feedback"><?= e($errors['ho_ten']) ?></div>
            <?php endif; ?>
        </div>

        <div class="row">
            <!-- Email -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Địa chỉ Email</label>
                <input type="email" name="email" class="form-control" placeholder="VD: mail@example.com" value="<?= e($val('email')) ?>">
            </div>

            <!-- Phone -->
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Số điện thoại</label>
                <input type="text" name="so_dien_thoai" class="form-control" placeholder="VD: 0987654321" value="<?= e($val('so_dien_thoai')) ?>">
            </div>
        </div>

        <!-- Password -->
        <div class="mb-4">
            <?php if ($isEdit): ?>
                <label class="form-label fw-semibold">Đặt lại mật khẩu mới (Bỏ trống nếu giữ nguyên)</label>
                <input type="password" name="new_password" class="form-control" placeholder="Nhập mật khẩu mới nếu muốn thay đổi...">
            <?php else: ?>
                <label class="form-label fw-semibold">Mật khẩu <span class="text-danger">*</span></label>
                <input type="password" name="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                       placeholder="Nhập mật khẩu..." required>
                <?php if (isset($errors['password'])): ?>
                    <div class="invalid-feedback"><?= e($errors['password']) ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-brand">
                <i class="fa-solid fa-save me-1"></i> <?= $isEdit ? 'Cập nhật tài khoản' : 'Tạo tài khoản' ?>
            </button>
            <a href="<?= BASE_URL ?>?action=admin-users" class="btn btn-outline-secondary">Hủy</a>
        </div>
        
    </form>
</div>
