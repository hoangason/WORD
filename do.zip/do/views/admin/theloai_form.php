<?php
$isEdit = isset($theLoai) && !empty($theLoai);
$formAction = $isEdit ? 'admin-theloai-update' : 'admin-theloai-store';
?>

<div class="card border-0 shadow-sm rounded-3 p-4 bg-white" style="max-width: 600px; margin: 0 auto;">
    
    <h4 class="fw-bold mb-4 border-bottom pb-2 text-dark">
        <i class="fa-solid fa-list-check text-success me-2"></i>
        <?= $isEdit ? 'Chỉnh sửa thể loại #' . e($theLoai['id_the_loai']) : 'Thêm thể loại mới' ?>
    </h4>

    <form action="<?= BASE_URL ?>?action=<?= $formAction ?>" method="POST">
        
        <?php if ($isEdit): ?>
            <input type="hidden" name="id_the_loai" value="<?= e($theLoai['id_the_loai']) ?>">
        <?php endif; ?>

        <div class="mb-4">
            <label class="form-label fw-semibold">Tên thể loại <span class="text-danger">*</span></label>
            <input type="text" name="ten_the_loai" class="form-control <?= isset($errors['ten_the_loai']) ? 'is-invalid' : '' ?>" 
                   placeholder="Nhập tên thể loại (VD: Khoa học viễn tưởng)"
                   value="<?= e($old['ten_the_loai'] ?? ($isEdit ? $theLoai['ten_the_loai'] : '')) ?>" required>
            <?php if (isset($errors['ten_the_loai'])): ?>
                <div class="invalid-feedback"><?= e($errors['ten_the_loai']) ?></div>
            <?php endif; ?>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-brand">
                <i class="fa-solid fa-save me-1"></i> <?= $isEdit ? 'Lưu thay đổi' : 'Thêm mới' ?>
            </button>
            <a href="<?= BASE_URL ?>?action=admin-theloai" class="btn btn-outline-secondary">Hủy</a>
        </div>
        
    </form>
</div>
