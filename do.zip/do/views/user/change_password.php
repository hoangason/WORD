<div class="row g-4">
    
    <!-- Profile sidebar menu -->
    <div class="col-md-4 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-3" style="background-color: #ffffff;">
            <div class="text-center py-3 border-bottom mb-3">
                <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center fw-bold shadow-sm mb-2" 
                     style="width: 70px; height: 70px; font-size: 2rem;">
                    <?= mb_substr(e($_SESSION['user']['ho_ten'] ?? $_SESSION['user']['username']), 0, 1) ?>
                </div>
                <h5 class="fw-bold mb-1 text-dark"><?= e($_SESSION['user']['ho_ten'] ?? $_SESSION['user']['username']) ?></h5>
                <span class="badge text-bg-<?= $_SESSION['user']['role'] === 'admin' ? 'danger' : 'success' ?>"><?= $_SESSION['user']['role'] === 'admin' ? 'Quản trị viên' : 'Thành viên' ?></span>
            </div>
            
            <div class="list-group list-group-flush">
                <a href="<?= BASE_URL ?>?action=profile" class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 text-dark">
                    <i class="fa-solid fa-id-card me-2"></i>Thông tin cá nhân
                </a>
                <a href="<?= BASE_URL ?>?action=change-password" class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 active bg-success text-white">
                    <i class="fa-solid fa-key me-2"></i>Đổi mật khẩu
                </a>
                <?php if (is_admin()): ?>
                    <a href="<?= BASE_URL ?>?action=admin" class="list-group-item list-group-item-action border-0 px-2 rounded-2 text-danger fw-semibold">
                        <i class="fa-solid fa-gauge-high me-2"></i>Trang quản trị (Admin)
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Password Form -->
    <div class="col-md-8 col-lg-9">
        <div class="card border-0 shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
            <h4 class="fw-bold mb-4 border-bottom pb-2 text-dark"><i class="fa-solid fa-lock me-2 text-success"></i>Đổi mật khẩu tài khoản</h4>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-4"><?= e($success) ?></div>
            <?php endif; ?>

            <form action="<?= BASE_URL ?>?action=do-change-password" method="POST">
                
                <!-- Current Password -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Mật khẩu hiện tại <span class="text-danger">*</span></label>
                    <input type="password" name="current_password" class="form-control <?= isset($errors['current_password']) ? 'is-invalid' : '' ?>" 
                           placeholder="Nhập mật khẩu hiện tại" required>
                    <?php if (isset($errors['current_password'])): ?>
                        <div class="invalid-feedback"><?= e($errors['current_password']) ?></div>
                    <?php endif; ?>
                </div>

                <!-- New Password -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Mật khẩu mới <span class="text-danger">*</span></label>
                    <input type="password" name="new_password" class="form-control <?= isset($errors['new_password']) ? 'is-invalid' : '' ?>" 
                           placeholder="Tối thiểu 4 ký tự" required>
                    <?php if (isset($errors['new_password'])): ?>
                        <div class="invalid-feedback"><?= e($errors['new_password']) ?></div>
                    <?php endif; ?>
                </div>

                <!-- Confirm New Password -->
                <div class="mb-4">
                    <label class="form-label fw-semibold">Xác nhận mật khẩu mới <span class="text-danger">*</span></label>
                    <input type="password" name="confirm_password" class="form-control <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>" 
                           placeholder="Nhập lại mật khẩu mới" required>
                    <?php if (isset($errors['confirm_password'])): ?>
                        <div class="invalid-feedback"><?= e($errors['confirm_password']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-brand"><i class="fa-solid fa-key me-1"></i> Đổi mật khẩu</button>
                    <a href="<?= BASE_URL ?>" class="btn btn-outline-secondary">Hủy</a>
                </div>
                
            </form>
        </div>
    </div>
    
</div>
