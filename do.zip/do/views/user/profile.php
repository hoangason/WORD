<div class="row g-4">
    
    <!-- Profile sidebar menu -->
    <div class="col-md-4 col-lg-3">
        <div class="card border-0 shadow-sm rounded-3 p-3" style="background-color: #ffffff;">
            <div class="text-center py-3 border-bottom mb-3">
                <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center fw-bold shadow-sm mb-2" 
                     style="width: 70px; height: 70px; font-size: 2rem;">
                    <?= mb_substr(e($user['ho_ten'] ?? $user['username']), 0, 1) ?>
                </div>
                <h5 class="fw-bold mb-1 text-dark"><?= e($user['ho_ten'] ?? $user['username']) ?></h5>
                <span class="badge text-bg-<?= $user['role'] === 'admin' ? 'danger' : 'success' ?>"><?= $user['role'] === 'admin' ? 'Quản trị viên' : 'Thành viên' ?></span>
            </div>
            
            <div class="list-group list-group-flush">
                <a href="<?= BASE_URL ?>?action=profile" class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 active bg-success text-white">
                    <i class="fa-solid fa-id-card me-2"></i>Thông tin cá nhân
                </a>
                <a href="<?= BASE_URL ?>?action=change-password" class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 text-dark">
                    <i class="fa-solid fa-key me-2"></i>Đổi mật khẩu
                </a>
                <?php if (is_admin()): ?>
                    <a href="<?= BASE_URL ?>?action=admin" class="list-group-item list-group-item-action border-0 px-2 rounded-2 text-danger fw-semibold">
                        <i class="fa-solid fa-gauge-high me-2"></i>Trang quản trị (Admin)
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Profile Form -->
    <div class="col-md-8 col-lg-9">
        <div class="card border-0 shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
            <h4 class="fw-bold mb-4 border-bottom pb-2 text-dark"><i class="fa-solid fa-user-pen me-2 text-success"></i>Cập nhật thông tin cá nhân</h4>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-4"><?= e($success) ?></div>
            <?php endif; ?>

            <form action="<?= BASE_URL ?>?action=update-profile" method="POST">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Tên đăng nhập (MSSV)</label>
                        <input type="text" class="form-control bg-light" value="<?= e($user['username']) ?>" readonly disabled>
                        <div class="form-text">Tên đăng nhập không thể thay đổi.</div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Quyền hạn</label>
                        <input type="text" class="form-control bg-light text-capitalize" value="<?= e($user['role']) ?>" readonly disabled>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Họ tên <span class="text-danger">*</span></label>
                    <input type="text" name="ho_ten" class="form-control <?= isset($errors['ho_ten']) ? 'is-invalid' : '' ?>" 
                           value="<?= e($user['ho_ten']) ?>" required>
                    <?php if (isset($errors['ho_ten'])): ?>
                        <div class="invalid-feedback"><?= e($errors['ho_ten']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Địa chỉ Email</label>
                        <input type="email" name="email" class="form-control" value="<?= e($user['email'] ?? '') ?>" placeholder="VD: sv@fpt.edu.vn">
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <label class="form-label fw-semibold">Số điện thoại</label>
                        <input type="text" name="so_dien_thoai" class="form-control" value="<?= e($user['so_dien_thoai'] ?? '') ?>" placeholder="VD: 0987654321">
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-brand"><i class="fa-solid fa-save me-1"></i> Lưu thay đổi</button>
                    <a href="<?= BASE_URL ?>" class="btn btn-outline-secondary">Hủy</a>
                </div>
                
            </form>
        </div>
    </div>
    
</div>
