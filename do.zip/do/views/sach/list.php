<div class="panel-box">

    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= e($success) ?></div>
    <?php endif; ?>

    <?php if (is_logged_in()): ?>
        <div class="mb-3 text-end">
            <a href="<?= BASE_URL ?>?action=sach-create" class="btn btn-brand">
                ＋ Thêm sách mới
            </a>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            Bạn cần <a href="<?= BASE_URL ?>?action=login">đăng nhập</a> để thêm, sửa hoặc xóa sách.
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr class="table-light">
                    <th>Mã sách</th>
                    <th>Ảnh bìa</th>
                    <th>Tên sách</th>
                    <th>Tác giả</th>
                    <th>Năm XB</th>
                    <th>NXB</th>
                    <th>Thể loại</th>
                    <?php if (is_logged_in()): ?>
                        <th class="text-center">Tác vụ</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($sachs)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">Chưa có dữ liệu sách nào.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($sachs as $sach): ?>
                        <tr>
                            <td>#<?= e($sach['id_sach']) ?></td>
                            <td>
                                <?php if (!empty($sach['hinh_anh'])): ?>
                                    <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt=""
                                         style="width:55px;height:75px;object-fit:cover;border-radius:6px;">
                                <?php else: ?>
                                    <span class="text-muted small">Chưa có ảnh</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= e($sach['ten_sach']) ?></strong></td>
                            <td><?= e($sach['tac_gia']) ?></td>
                            <td><?= e($sach['nam_xuat_ban']) ?></td>
                            <td><?= e($sach['nha_xuat_ban']) ?></td>
                            <td>
                                <span class="badge rounded-pill text-bg-light border">
                                    <?= e($sach['ten_the_loai'] ?? 'Chưa phân loại') ?>
                                </span>
                            </td>
                            <?php if (is_logged_in()): ?>
                                <td class="text-center text-nowrap">
                                    <a href="<?= BASE_URL ?>?action=sach-edit&id=<?= $sach['id_sach'] ?>"
                                       class="btn btn-sm btn-outline-secondary">Sửa</a>

                                    <a href="<?= BASE_URL ?>?action=sach-delete&id=<?= $sach['id_sach'] ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Xác nhận xóa sách \'<?= e($sach['ten_sach']) ?>\'?');">
                                        Xóa
                                    </a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
