<div class="panel-box" style="max-width: 650px; margin: 0 auto;">

    <?php
    $isEdit     = isset($sach) && !empty($sach);
    $formAction = $isEdit ? 'sach-update' : 'sach-store';

    $val = function ($field) use ($old, $isEdit, $sach) {
        if (isset($old[$field])) {
            return $old[$field];
        }
        if ($isEdit && isset($sach[$field])) {
            return $sach[$field];
        }
        return '';
    };
    ?>

    <form action="<?= BASE_URL ?>?action=<?= $formAction ?>" method="POST" enctype="multipart/form-data">

        <?php if ($isEdit): ?>
            <input type="hidden" name="id_sach" value="<?= e($sach['id_sach']) ?>">
        <?php endif; ?>

        <div class="mb-3">
            <label class="form-label fw-semibold">Tên sách <span class="text-danger">*</span></label>
            <input type="text" name="ten_sach" class="form-control <?= isset($errors['ten_sach']) ? 'is-invalid' : '' ?>"
                   value="<?= e($val('ten_sach')) ?>">
            <?php if (isset($errors['ten_sach'])): ?>
                <div class="invalid-feedback"><?= e($errors['ten_sach']) ?></div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Tác giả</label>
                <input type="text" name="tac_gia" class="form-control" value="<?= e($val('tac_gia')) ?>">
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Năm xuất bản</label>
                <input type="number" name="nam_xuat_ban" class="form-control <?= isset($errors['nam_xuat_ban']) ? 'is-invalid' : '' ?>"
                       placeholder="VD: 2020" min="1900" max="<?= date('Y') ?>"
                       value="<?= e($val('nam_xuat_ban')) ?>">
                <?php if (isset($errors['nam_xuat_ban'])): ?>
                    <div class="invalid-feedback"><?= e($errors['nam_xuat_ban']) ?></div>
                <?php else: ?>
                    <div class="form-text">Không được lớn hơn năm hiện tại (<?= date('Y') ?>).</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Nhà xuất bản</label>
            <input type="text" name="nha_xuat_ban" class="form-control" value="<?= e($val('nha_xuat_ban')) ?>">
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Thể loại</label>
            <select name="id_the_loai" class="form-select">
                <option value="">-- Chọn thể loại --</option>
                <?php
                $selectedTheLoaiId = $old['id_the_loai'] ?? ($isEdit ? $sach['id_the_loai'] : null);
                foreach ($theLoais as $theLoai):
                ?>
                    <option value="<?= $theLoai['id_the_loai'] ?>"
                        <?= ((string) $selectedTheLoaiId === (string) $theLoai['id_the_loai']) ? 'selected' : '' ?>>
                        <?= e($theLoai['ten_the_loai']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="form-label fw-semibold">Ảnh bìa sách</label>
            <input type="file" name="hinh_anh" class="form-control <?= isset($errors['hinh_anh']) ? 'is-invalid' : '' ?>" accept="image/*">
            <?php if (isset($errors['hinh_anh'])): ?>
                <div class="invalid-feedback"><?= e($errors['hinh_anh']) ?></div>
            <?php endif; ?>

            <?php if ($isEdit && !empty($sach['hinh_anh'])): ?>
                <div class="mt-2 d-flex align-items-center gap-2">
                    <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt=""
                         style="width:70px;height:95px;object-fit:cover;border-radius:6px;">
                    <small class="text-muted">Ảnh hiện tại — giữ nguyên nếu không chọn ảnh mới.</small>
                </div>
            <?php endif; ?>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-brand">
                <?= $isEdit ? 'Lưu thay đổi' : 'Thêm sách' ?>
            </button>
            <a href="<?= BASE_URL ?>" class="btn btn-outline-secondary">Hủy</a>
        </div>

    </form>

</div>
