<div class="card border-0 shadow-sm rounded-3 p-4 mb-4" style="background-color: #ffffff;">
    <div class="row g-4">
        
        <!-- Left Side: Cover Image -->
        <div class="col-md-4 text-center">
            <div class="bg-light p-3 rounded-3 d-inline-block shadow-sm mb-3 w-100" style="max-width: 320px;">
                <?php if (!empty($sach['hinh_anh'])): ?>
                    <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt="<?= e($sach['ten_sach']) ?>" 
                         class="img-fluid rounded-2 shadow-sm" style="max-height: 400px; object-fit: cover;">
                <?php else: ?>
                    <div class="d-flex flex-column align-items-center justify-content-center bg-white text-muted p-5 rounded-2" style="height: 380px;">
                        <i class="fa-solid fa-book fs-1 mb-3"></i>
                        <span>Chưa có ảnh bìa</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Right Side: Product Details -->
        <div class="col-md-8">
            <div class="d-flex align-items-center gap-2 mb-2">
                <span class="badge bg-success rounded-pill px-3 py-2"><?= e($sach['ten_the_loai'] ?? 'Chưa phân loại') ?></span>
                <span class="text-muted small">Mã sách: #<?= e($sach['id_sach']) ?></span>
            </div>

            <h1 class="fw-bold text-dark mb-3"><?= e($sach['ten_sach']) ?></h1>
            
            <div class="fs-3 fw-bold text-danger mb-4">
                <?= !empty($sach['gia']) ? number_format($sach['gia']) . ' đ' : 'Liên hệ' ?>
            </div>

            <!-- Specs Grid -->
            <div class="row g-3 mb-4 bg-light p-3 rounded-3">
                <div class="col-sm-6">
                    <span class="text-muted d-block small">Tác giả</span>
                    <strong class="text-dark"><?= e($sach['tac_gia'] ?: 'Chưa cập nhật') ?></strong>
                </div>
                <div class="col-sm-6">
                    <span class="text-muted d-block small">Nhà xuất bản</span>
                    <strong class="text-dark"><?= e($sach['nha_xuat_ban'] ?: 'Chưa cập nhật') ?></strong>
                </div>
                <div class="col-sm-6">
                    <span class="text-muted d-block small">Năm xuất bản</span>
                    <strong class="text-dark"><?= e($sach['nam_xuat_ban'] ?: 'Chưa cập nhật') ?></strong>
                </div>
                <div class="col-sm-6">
                    <span class="text-muted d-block small">Số lượng còn lại</span>
                    <strong class="text-dark"><?= e($sach['so_luong']) ?> cuốn</strong>
                </div>
            </div>

            <!-- Description -->
            <div class="mb-4">
                <h5 class="fw-bold border-bottom pb-2 mb-3">Mô tả nội dung</h5>
                <p class="text-secondary" style="line-height: 1.6; white-space: pre-line;">
                    <?= e($sach['mo_ta'] ?: 'Chưa có thông tin mô tả chi tiết cho cuốn sách này.') ?>
                </p>
            </div>
            
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>?action=san-pham" class="btn btn-outline-brand">
                    <i class="fa-solid fa-arrow-left me-1"></i> Quay lại
                </a>
            </div>
        </div>
        
    </div>
</div>

<!-- Comments Section (Ý 3.3) -->
<div class="card border-0 shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
    <h4 class="fw-bold mb-4 text-dark d-flex align-items-center gap-2">
        <i class="fa-regular fa-comments text-success"></i> Đánh giá & Bình luận (<?= count($comments) ?>)
    </h4>

    <!-- Success/Error comment alerts -->
    <?php if (isset($comment_success)): ?>
        <div class="alert alert-success border-0 shadow-sm"><?= e($comment_success) ?></div>
    <?php endif; ?>
    <?php if (isset($comment_error)): ?>
        <div class="alert alert-danger border-0 shadow-sm"><?= e($comment_error) ?></div>
    <?php endif; ?>

    <!-- Comment Form -->
    <div class="mb-5 bg-light p-3 rounded-3">
        <?php if (is_logged_in()): ?>
            <h6 class="fw-bold mb-3 text-dark">Viết bình luận của bạn</h6>
            <form action="<?= BASE_URL ?>?action=comment-store" method="POST">
                <input type="hidden" name="id_sach" value="<?= e($sach['id_sach']) ?>">
                <div class="mb-3">
                    <textarea class="form-control" name="noi_dung" rows="3" placeholder="Nhập nội dung nhận xét, đánh giá của bạn về cuốn sách này..." required></textarea>
                </div>
                <div class="text-end">
                    <button class="btn btn-brand" type="submit"><i class="fa-regular fa-paper-plane me-1"></i> Gửi bình luận</button>
                </div>
            </form>
        <?php else: ?>
            <div class="text-center py-3">
                <p class="text-muted mb-2">Bạn cần đăng nhập để có thể bình luận về cuốn sách này.</p>
                <a href="<?= BASE_URL ?>?action=login" class="btn btn-outline-brand btn-sm">Đăng nhập ngay</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Comments List -->
    <div class="comments-list">
        <?php if (empty($comments)): ?>
            <div class="text-center text-muted py-4">
                <i class="fa-solid fa-comments fs-2 mb-2 text-secondary"></i>
                <p>Chưa có bình luận nào cho cuốn sách này. Hãy là người đầu tiên nhận xét!</p>
            </div>
        <?php else: ?>
            <?php foreach ($comments as $comment): ?>
                <div class="d-flex gap-3 mb-4 pb-3 border-bottom">
                    <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" 
                         style="width: 42px; height: 42px; min-width: 42px; font-size: 1.1rem;">
                        <?= mb_substr(e($comment['ho_ten'] ?? $comment['username']), 0, 1) ?>
                    </div>
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <strong class="text-dark"><?= e($comment['ho_ten'] ?? $comment['username']) ?></strong>
                            <span class="text-muted small">• <?= date('d/m/Y H:i', strtotime($comment['ngay_binh_luan'])) ?></span>
                        </div>
                        <p class="text-secondary mb-0" style="font-size: 0.95rem; white-space: pre-line;"><?= e($comment['noi_dung']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
