<div class="row g-4">
    
    <!-- Sidebar Filters -->
    <div class="col-lg-3">
        
        <!-- Search Box -->
        <div class="card border-0 shadow-sm rounded-3 p-3 mb-4" style="background-color: #ffffff;">
            <h5 class="fw-bold mb-3 text-dark"><i class="fa-solid fa-magnifying-glass me-2 text-success"></i>Tìm kiếm</h5>
            <form action="<?= BASE_URL ?>" method="GET">
                <input type="hidden" name="action" value="san-pham">
                <?php if (!empty($idTheLoai)): ?>
                    <input type="hidden" name="id_the_loai" value="<?= e($idTheLoai) ?>">
                <?php endif; ?>
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Tên sách, tác giả..." 
                           value="<?= e($keyword) ?>">
                    <button class="btn btn-brand" type="submit"><i class="fa-solid fa-search"></i></button>
                </div>
                <?php if (!empty($keyword) || !empty($idTheLoai)): ?>
                    <div class="mt-2 text-end">
                        <a href="<?= BASE_URL ?>?action=san-pham" class="text-danger small text-decoration-none">
                            <i class="fa-solid fa-circle-xmark"></i> Xóa bộ lọc
                        </a>
                    </div>
                <?php endif; ?>
            </form>
        </div>

        <!-- Categories List -->
        <div class="card border-0 shadow-sm rounded-3 p-3" style="background-color: #ffffff;">
            <h5 class="fw-bold mb-3 text-dark"><i class="fa-solid fa-layer-group me-2 text-success"></i>Thể loại</h5>
            <div class="list-group list-group-flush">
                <a href="<?= BASE_URL ?>?action=san-pham<?= !empty($keyword) ? '&keyword='.urlencode($keyword) : '' ?>" 
                   class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 d-flex align-items-center justify-content-between <?= empty($idTheLoai) ? 'active bg-success text-white' : '' ?>">
                    <span>Tất cả thể loại</span>
                    <i class="fa-solid fa-angle-right small"></i>
                </a>
                <?php foreach ($theLoais as $theLoai): ?>
                    <a href="<?= BASE_URL ?>?action=san-pham&id_the_loai=<?= $theLoai['id_the_loai'] ?><?= !empty($keyword) ? '&keyword='.urlencode($keyword) : '' ?>" 
                       class="list-group-item list-group-item-action border-0 px-2 rounded-2 mb-1 d-flex align-items-center justify-content-between <?= ((string)$idTheLoai === (string)$theLoai['id_the_loai']) ? 'active bg-success text-white' : '' ?>">
                        <span><?= e($theLoai['ten_the_loai']) ?></span>
                        <i class="fa-solid fa-angle-right small"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
    </div>

    <!-- Product Grid -->
    <div class="col-lg-9">
        <div class="card border-0 shadow-sm rounded-3 p-4" style="background-color: #ffffff;">
            
            <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
                <div>
                    <h4 class="fw-bold mb-0">
                        <?= !empty($selectedCategoryName) ? 'Thể loại: ' . e($selectedCategoryName) : 'Tất cả sách' ?>
                    </h4>
                    <?php if (!empty($keyword)): ?>
                        <span class="text-muted small">Kết quả tìm kiếm cho từ khóa: "<strong><?= e($keyword) ?></strong>"</span>
                    <?php endif; ?>
                </div>
                <span class="badge bg-success py-2 px-3 fs-6 rounded-pill"><?= count($sachs) ?> sản phẩm</span>
            </div>

            <div class="row g-4">
                <?php if (empty($sachs)): ?>
                    <div class="col-12 text-center text-muted py-5">
                        <i class="fa-regular fa-folder-open fs-1 mb-3 text-secondary"></i>
                        <p>Không tìm thấy cuốn sách nào phù hợp với yêu cầu của bạn.</p>
                        <a href="<?= BASE_URL ?>?action=san-pham" class="btn btn-brand btn-sm">Xem tất cả sách</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($sachs as $sach): ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="card-product">
                                <div class="card-product-img">
                                    <?php if (!empty($sach['hinh_anh'])): ?>
                                        <img src="<?= BASE_ASSETS_UPLOADS . e($sach['hinh_anh']) ?>" alt="<?= e($sach['ten_sach']) ?>">
                                    <?php else: ?>
                                        <div class="d-flex flex-column align-items-center justify-content-center h-100 bg-light text-muted p-3">
                                            <i class="fa-solid fa-book fs-1 mb-2"></i>
                                            <span class="small">Chưa có ảnh bìa</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-product-body">
                                    <span class="badge rounded-pill text-bg-light border mb-2 me-auto"><?= e($sach['ten_the_loai'] ?? 'Chưa phân loại') ?></span>
                                    <h5 class="card-product-title" title="<?= e($sach['ten_sach']) ?>">
                                        <a href="<?= BASE_URL ?>?action=sach-detail&id=<?= $sach['id_sach'] ?>" class="text-decoration-none text-dark">
                                            <?= e($sach['ten_sach']) ?>
                                        </a>
                                    </h5>
                                    <p class="card-product-author mb-1">Tác giả: <strong><?= e($sach['tac_gia'] ?: 'Chưa rõ') ?></strong></p>
                                    <p class="small text-muted mb-2">Năm XB: <?= e($sach['nam_xuat_ban'] ?: 'Chưa cập nhật') ?></p>
                                    
                                    <div class="d-flex align-items-center justify-content-between mt-auto pt-2 border-top">
                                        <span class="card-product-price text-danger fw-bold">
                                            <?= !empty($sach['gia']) ? number_format($sach['gia']) . ' đ' : 'Liên hệ' ?>
                                        </span>
                                        <a href="<?= BASE_URL ?>?action=sach-detail&id=<?= $sach['id_sach'] ?>" class="btn btn-sm btn-brand">Chi tiết</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
    
</div>
